/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const getConnectionsTable = /* GraphQL */ `
  query GetConnectionsTable($userID: String!) {
    getConnectionsTable(userID: $userID) {
      friends
      received
      sent
      userID
    }
  }
`;
export const getExpertiseTable = /* GraphQL */ `
  query GetExpertiseTable($domainVal: String!) {
    getExpertiseTable(domainVal: $domainVal) {
      domainVal
      userIDList
    }
  }
`;
export const getInterestsTable = /* GraphQL */ `
  query GetInterestsTable($interest_name: String!) {
    getInterestsTable(interest_name: $interest_name) {
      interest_name
      user_id_list
    }
  }
`;
export const getNotifications = /* GraphQL */ `
  query GetNotifications($receiveruserID: String!) {
    getNotifications(receiveruserID: $receiveruserID) {
      SenderStatus
      receiveruserID
    }
  }
`;
export const getProfile = /* GraphQL */ `
  query GetProfile($userid: String!) {
    getProfile(userid: $userid) {
      bio
      business_interests
      connections
      email
      events
      expert_in
      gender
      id
      name
      perks
      phone_number
      role
      userid
    }
  }
`;
export const listConnectionsTables = /* GraphQL */ `
  query ListConnectionsTables(
    $filter: TableConnectionsTableFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listConnectionsTables(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        friends
        received
        sent
        userID
      }
      nextToken
    }
  }
`;
export const listExpertiseTables = /* GraphQL */ `
  query ListExpertiseTables(
    $filter: TableExpertiseTableFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listExpertiseTables(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        domainVal
        userIDList
      }
      nextToken
    }
  }
`;
export const listInterestsTables = /* GraphQL */ `
  query ListInterestsTables(
    $filter: TableInterestsTableFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listInterestsTables(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        interest_name
        user_id_list
      }
      nextToken
    }
  }
`;
export const listNotifications = /* GraphQL */ `
  query ListNotifications(
    $filter: TableNotificationsFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listNotifications(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        SenderStatus
        receiveruserID
      }
      nextToken
    }
  }
`;
export const listProfiles = /* GraphQL */ `
  query ListProfiles(
    $filter: TableProfileFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listProfiles(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        bio
        business_interests
        connections
        email
        events
        expert_in
        gender
        id
        name
        perks
        phone_number
        role
        userid
      }
      nextToken
    }
  }
`;
export const single = /* GraphQL */ `
  query Single($userid: String!) {
    single(userid: $userid) {
      bio
      business_interests
      connections
      email
      events
      expert_in
      gender
      id
      name
      perks
      phone_number
      role
      userid
    }
  }
`;
export const getMessage = /* GraphQL */ `
  query GetMessage($id: ID!) {
    getMessage(id: $id) {
      author
      body
      channelID
      createdAt
      id
      updatedAt
    }
  }
`;
export const getUserChannnelData = /* GraphQL */ `
  query GetUserChannnelData($userid: String!) {
    getUserChannnelData(userid: $userid) {
      activechannelandusers
      userid
    }
  }
`;
export const listMessages = /* GraphQL */ `
  query ListMessages(
    $filter: ModelMessageFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listMessages(filter: $filter, limit: $limit, nextToken: $nextToken) {
      items {
        author
        body
        channelID
        createdAt
        id
        updatedAt
      }
      nextToken
    }
  }
`;
export const listUserChannnelData = /* GraphQL */ `
  query ListUserChannnelData(
    $filter: TableUserChannnelDataFilterInput
    $limit: Int
    $nextToken: String
  ) {
    listUserChannnelData(
      filter: $filter
      limit: $limit
      nextToken: $nextToken
    ) {
      items {
        activechannelandusers
        userid
      }
      nextToken
    }
  }
`;
export const messagesByChannelID = /* GraphQL */ `
  query MessagesByChannelID(
    $channelID: ID
    $createdAt: ModelStringKeyConditionInput
    $filter: ModelMessageFilterInput
    $limit: Int
    $nextToken: String
    $sortDirection: ModelSortDirection
  ) {
    messagesByChannelID(
      channelID: $channelID
      createdAt: $createdAt
      filter: $filter
      limit: $limit
      nextToken: $nextToken
      sortDirection: $sortDirection
    ) {
      items {
        author
        body
        channelID
        createdAt
        id
        updatedAt
      }
      nextToken
    }
  }
`;
