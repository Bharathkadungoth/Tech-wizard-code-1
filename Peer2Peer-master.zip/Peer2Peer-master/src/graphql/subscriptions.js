/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const onCreateConnectionsTable = /* GraphQL */ `
  subscription OnCreateConnectionsTable(
    $friends: [String]
    $received: [String]
    $sent: [String]
    $userID: String
  ) {
    onCreateConnectionsTable(
      friends: $friends
      received: $received
      sent: $sent
      userID: $userID
    ) {
      friends
      received
      sent
      userID
    }
  }
`;
export const onCreateExpertiseTable = /* GraphQL */ `
  subscription OnCreateExpertiseTable(
    $domainVal: String
    $userIDList: [String]
  ) {
    onCreateExpertiseTable(domainVal: $domainVal, userIDList: $userIDList) {
      domainVal
      userIDList
    }
  }
`;
export const onCreateInterestsTable = /* GraphQL */ `
  subscription OnCreateInterestsTable(
    $interest_name: String
    $user_id_list: [String]
  ) {
    onCreateInterestsTable(
      interest_name: $interest_name
      user_id_list: $user_id_list
    ) {
      interest_name
      user_id_list
    }
  }
`;
export const onCreateNotifications = /* GraphQL */ `
  subscription OnCreateNotifications(
    $SenderStatus: [String]
    $receiveruserID: String
  ) {
    onCreateNotifications(
      SenderStatus: $SenderStatus
      receiveruserID: $receiveruserID
    ) {
      SenderStatus
      receiveruserID
    }
  }
`;
export const onCreateProfile = /* GraphQL */ `
  subscription OnCreateProfile(
    $gender: String
    $id: ID
    $name: String
    $phone_number: AWSPhone
    $userid: String
  ) {
    onCreateProfile(
      gender: $gender
      id: $id
      name: $name
      phone_number: $phone_number
      userid: $userid
    ) {
      bio
      business_interests
      connections
      email
      events
      expert_in
      gender
      id
      name
      perks
      phone_number
      role
      userid
    }
  }
`;
export const onDeleteConnectionsTable = /* GraphQL */ `
  subscription OnDeleteConnectionsTable(
    $friends: [String]
    $received: [String]
    $sent: [String]
    $userID: String
  ) {
    onDeleteConnectionsTable(
      friends: $friends
      received: $received
      sent: $sent
      userID: $userID
    ) {
      friends
      received
      sent
      userID
    }
  }
`;
export const onDeleteExpertiseTable = /* GraphQL */ `
  subscription OnDeleteExpertiseTable(
    $domainVal: String
    $userIDList: [String]
  ) {
    onDeleteExpertiseTable(domainVal: $domainVal, userIDList: $userIDList) {
      domainVal
      userIDList
    }
  }
`;
export const onDeleteInterestsTable = /* GraphQL */ `
  subscription OnDeleteInterestsTable(
    $interest_name: String
    $user_id_list: [String]
  ) {
    onDeleteInterestsTable(
      interest_name: $interest_name
      user_id_list: $user_id_list
    ) {
      interest_name
      user_id_list
    }
  }
`;
export const onDeleteNotifications = /* GraphQL */ `
  subscription OnDeleteNotifications(
    $SenderStatus: [String]
    $receiveruserID: String
  ) {
    onDeleteNotifications(
      SenderStatus: $SenderStatus
      receiveruserID: $receiveruserID
    ) {
      SenderStatus
      receiveruserID
    }
  }
`;
export const onDeleteProfile = /* GraphQL */ `
  subscription OnDeleteProfile(
    $gender: String
    $id: ID
    $name: String
    $phone_number: AWSPhone
    $userid: String
  ) {
    onDeleteProfile(
      gender: $gender
      id: $id
      name: $name
      phone_number: $phone_number
      userid: $userid
    ) {
      bio
      business_interests
      connections
      email
      events
      expert_in
      gender
      id
      name
      perks
      phone_number
      role
      userid
    }
  }
`;
export const onUpdateConnectionsTable = /* GraphQL */ `
  subscription OnUpdateConnectionsTable(
    $friends: [String]
    $received: [String]
    $sent: [String]
    $userID: String
  ) {
    onUpdateConnectionsTable(
      friends: $friends
      received: $received
      sent: $sent
      userID: $userID
    ) {
      friends
      received
      sent
      userID
    }
  }
`;
export const onUpdateExpertiseTable = /* GraphQL */ `
  subscription OnUpdateExpertiseTable(
    $domainVal: String
    $userIDList: [String]
  ) {
    onUpdateExpertiseTable(domainVal: $domainVal, userIDList: $userIDList) {
      domainVal
      userIDList
    }
  }
`;
export const onUpdateInterestsTable = /* GraphQL */ `
  subscription OnUpdateInterestsTable(
    $interest_name: String
    $user_id_list: [String]
  ) {
    onUpdateInterestsTable(
      interest_name: $interest_name
      user_id_list: $user_id_list
    ) {
      interest_name
      user_id_list
    }
  }
`;
export const onUpdateNotifications = /* GraphQL */ `
  subscription OnUpdateNotifications(
    $SenderStatus: [String]
    $receiveruserID: String
  ) {
    onUpdateNotifications(
      SenderStatus: $SenderStatus
      receiveruserID: $receiveruserID
    ) {
      SenderStatus
      receiveruserID
    }
  }
`;
export const onUpdateProfile = /* GraphQL */ `
  subscription OnUpdateProfile(
    $gender: String
    $id: ID
    $name: String
    $phone_number: AWSPhone
    $userid: String
  ) {
    onUpdateProfile(
      gender: $gender
      id: $id
      name: $name
      phone_number: $phone_number
      userid: $userid
    ) {
      bio
      business_interests
      connections
      email
      events
      expert_in
      gender
      id
      name
      perks
      phone_number
      role
      userid
    }
  }
`;
export const onCreateMessage = /* GraphQL */ `
  subscription OnCreateMessage($channelID: ID!) {
    onCreateMessage(channelID: $channelID) {
      author
      body
      channelID
      createdAt
      id
      updatedAt
    }
  }
`;
export const onCreateUserChannnelData = /* GraphQL */ `
  subscription OnCreateUserChannnelData(
    $activechannelandusers: [String]
    $id: ID
  ) {
    onCreateUserChannnelData(
      activechannelandusers: $activechannelandusers
      id: $id
    ) {
      activechannelandusers
      userid
    }
  }
`;
export const onDeleteMessage = /* GraphQL */ `
  subscription OnDeleteMessage {
    onDeleteMessage {
      author
      body
      channelID
      createdAt
      id
      updatedAt
    }
  }
`;
export const onDeleteUserChannnelData = /* GraphQL */ `
  subscription OnDeleteUserChannnelData(
    $activechannelandusers: [String]
    $id: ID
  ) {
    onDeleteUserChannnelData(
      activechannelandusers: $activechannelandusers
      id: $id
    ) {
      activechannelandusers
      userid
    }
  }
`;
export const onUpdateMessage = /* GraphQL */ `
  subscription OnUpdateMessage {
    onUpdateMessage {
      author
      body
      channelID
      createdAt
      id
      updatedAt
    }
  }
`;
export const onUpdateUserChannnelData = /* GraphQL */ `
  subscription OnUpdateUserChannnelData(
    $activechannelandusers: [String]
    $id: ID
  ) {
    onUpdateUserChannnelData(
      activechannelandusers: $activechannelandusers
      id: $id
    ) {
      activechannelandusers
      userid
    }
  }
`;
