/* eslint-disable */
// this is an auto generated file. This will be overwritten

export const createConnectionsTable = /* GraphQL */ `
  mutation CreateConnectionsTable($input: CreateConnectionsTableInput!) {
    createConnectionsTable(input: $input) {
      friends
      received
      sent
      userID
    }
  }
`;
export const createExpertiseTable = /* GraphQL */ `
  mutation CreateExpertiseTable($input: CreateExpertiseTableInput!) {
    createExpertiseTable(input: $input) {
      domainVal
      userIDList
    }
  }
`;
export const createInterestsTable = /* GraphQL */ `
  mutation CreateInterestsTable($input: CreateInterestsTableInput!) {
    createInterestsTable(input: $input) {
      interest_name
      user_id_list
    }
  }
`;
export const createNotifications = /* GraphQL */ `
  mutation CreateNotifications($input: CreateNotificationsInput!) {
    createNotifications(input: $input) {
      SenderStatus
      receiveruserID
    }
  }
`;
export const createProfile = /* GraphQL */ `
  mutation CreateProfile($input: CreateProfileInput!) {
    createProfile(input: $input) {
      bio
      business_interests
      connections
      email
      events
      expert_in
      gender
      id
      name
      perks
      phone_number
      role
      userid
    }
  }
`;
export const deleteConnectionsTable = /* GraphQL */ `
  mutation DeleteConnectionsTable($input: DeleteConnectionsTableInput!) {
    deleteConnectionsTable(input: $input) {
      friends
      received
      sent
      userID
    }
  }
`;
export const deleteExpertiseTable = /* GraphQL */ `
  mutation DeleteExpertiseTable($input: DeleteExpertiseTableInput!) {
    deleteExpertiseTable(input: $input) {
      domainVal
      userIDList
    }
  }
`;
export const deleteInterestsTable = /* GraphQL */ `
  mutation DeleteInterestsTable($input: DeleteInterestsTableInput!) {
    deleteInterestsTable(input: $input) {
      interest_name
      user_id_list
    }
  }
`;
export const deleteNotifications = /* GraphQL */ `
  mutation DeleteNotifications($input: DeleteNotificationsInput!) {
    deleteNotifications(input: $input) {
      SenderStatus
      receiveruserID
    }
  }
`;
export const deleteProfile = /* GraphQL */ `
  mutation DeleteProfile($input: DeleteProfileInput!) {
    deleteProfile(input: $input) {
      bio
      business_interests
      connections
      email
      events
      expert_in
      gender
      id
      name
      perks
      phone_number
      role
      userid
    }
  }
`;
export const updateConnectionsTable = /* GraphQL */ `
  mutation UpdateConnectionsTable($input: UpdateConnectionsTableInput!) {
    updateConnectionsTable(input: $input) {
      friends
      received
      sent
      userID
    }
  }
`;
export const updateExpertiseTable = /* GraphQL */ `
  mutation UpdateExpertiseTable($input: UpdateExpertiseTableInput!) {
    updateExpertiseTable(input: $input) {
      domainVal
      userIDList
    }
  }
`;
export const updateInterestsTable = /* GraphQL */ `
  mutation UpdateInterestsTable($input: UpdateInterestsTableInput!) {
    updateInterestsTable(input: $input) {
      interest_name
      user_id_list
    }
  }
`;
export const updateNotifications = /* GraphQL */ `
  mutation UpdateNotifications($input: UpdateNotificationsInput!) {
    updateNotifications(input: $input) {
      SenderStatus
      receiveruserID
    }
  }
`;
export const updateProfile = /* GraphQL */ `
  mutation UpdateProfile($input: UpdateProfileInput!) {
    updateProfile(input: $input) {
      bio
      business_interests
      connections
      email
      events
      expert_in
      gender
      id
      name
      perks
      phone_number
      role
      userid
    }
  }
`;
export const createMessage = /* GraphQL */ `
  mutation CreateMessage(
    $condition: ModelMessageConditionInput
    $input: CreateMessageInput!
  ) {
    createMessage(condition: $condition, input: $input) {
      author
      body
      channelID
      createdAt
      id
      updatedAt
    }
  }
`;
export const createUserChannnelData = /* GraphQL */ `
  mutation CreateUserChannnelData($input: CreateUserChannnelDataInput!) {
    createUserChannnelData(input: $input) {
      activechannelandusers
      userid
    }
  }
`;
export const deleteMessage = /* GraphQL */ `
  mutation DeleteMessage(
    $condition: ModelMessageConditionInput
    $input: DeleteMessageInput!
  ) {
    deleteMessage(condition: $condition, input: $input) {
      author
      body
      channelID
      createdAt
      id
      updatedAt
    }
  }
`;
export const deleteUserChannnelData = /* GraphQL */ `
  mutation DeleteUserChannnelData($input: DeleteUserChannnelDataInput!) {
    deleteUserChannnelData(input: $input) {
      activechannelandusers
      userid
    }
  }
`;
export const updateMessage = /* GraphQL */ `
  mutation UpdateMessage(
    $condition: ModelMessageConditionInput
    $input: UpdateMessageInput!
  ) {
    updateMessage(condition: $condition, input: $input) {
      author
      body
      channelID
      createdAt
      id
      updatedAt
    }
  }
`;
export const updateUserChannnelData = /* GraphQL */ `
  mutation UpdateUserChannnelData($input: UpdateUserChannnelDataInput!) {
    updateUserChannnelData(input: $input) {
      activechannelandusers
      userid
    }
  }
`;
