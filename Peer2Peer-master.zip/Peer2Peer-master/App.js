/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj, Rishika Bera, Swarnalatha Srenigarajan
 * @createdOn : 02-11-21
 * @modifiedOn : 04-21-21
 * @description : Contains the main App & the screens it can navigate to.
 *================================================================================================**/

import * as React from "react";
import InitialScreen from "./screens/InitialScreen";
import ProfileScreen from "./screens/Dashboard/ProfileScreen";
import ChatScreen from "./screens/Dashboard/chatScreen";
import RegisterScreen from "./screens/Initial/RegisterScreen";
import EditProfileScreen from "./screens/Dashboard/EditProfileScreen";
import Dashboard from "./screens/Dashboard";
import ChatInvocation from "./screens/Dashboard/chatInvocation";
import ForgotPasswordScreen from "./screens/Initial/ForgotPasswordScreen";
import Welcome from "./screens/welcome";
import AboutUs from "./screens/Dashboard/aboutus";

import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

const Stack = createStackNavigator();

export default function RootStack() {
    return (
        <NavigationContainer>
            <Stack.Navigator
                initialRouteName="Welcome"
                screenOptions={{ gestureEnabled: false }}
            >
                <Stack.Screen
                    name="InitialScreen"
                    component={InitialScreen}
                    options={{ title: "Peer2Peer", headerLeft: () => null }}
                />
                <Stack.Screen
                    name="Register"
                    component={RegisterScreen}
                    options={{ headerLeft: () => null }}
                />

                <Stack.Screen
                    name="EditProfile"
                    component={EditProfileScreen}
                    options={{ title: "Edit Profile" }}
                />
                <Stack.Screen
                    name="ForgotPassword"
                    component={ForgotPasswordScreen}
                    initialParams={{ user: "me" }}
                />
                <Stack.Screen
                    name="ChatInvocation"
                    component={ChatInvocation}
                />
                <Stack.Screen name="Chat" component={ChatScreen} />
                <Stack.Screen
                    name="Dashboard"
                    component={Dashboard}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="Welcome"
                    component={Welcome}
                    options={{
                        headerShown: false,
                    }}
                />
                <Stack.Screen
                    name="AboutUs"
                    component={AboutUs}
                    options={{
                        headerStyle: {
                            backgroundColor: "wheat",
                        },
                    }}
                />
            </Stack.Navigator>
        </NavigationContainer>
    );
}
