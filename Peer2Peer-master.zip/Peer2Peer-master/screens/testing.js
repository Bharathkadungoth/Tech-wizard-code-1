/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj
 * @createdOn : 02-22-21
 * @modifiedOn : 04-15-21
 * @description : Contains the components used to display the Profile of any user.
 *================================================================================================**/

import React, { useState, Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    ScrollView,
    TouchableOpacity,
    Image,
    Modal,
    FlatList,
    TouchableHighlight,
} from "react-native";
import { Icon } from "react-native-elements";
import Lightbox from "react-native-lightbox";
import axios from "axios";
import UserAvatar from "react-native-user-avatar";
import { Divider } from "react-native-paper";

import SearchBar from "./searchBar";

//query database
import Amplify from "aws-amplify";
import { API, graphqlOperation } from "aws-amplify";
import config from "../aws-exports";
Amplify.configure(config);
import { listProfiles } from "../src/graphql/queries";

var user, name, about, img_wall, img_profile, conn;
async function componentDidMount() {
    try {
        const profiles = await API.graphql(graphqlOperation(listProfiles));
        user = profiles.data.listProfiles.items;
        console.log(profiles.data.listProfiles.items);
    } catch (err) {
        console.log("error: ", err);
    }
}

//create a profile
import {
    createProfile,
    updateProfile,
    deleteProfile,
} from "../src/graphql/mutations";

//get profile by ID
import * as queries from "../src/graphql/queries";

async function getProfilebyID() {
    try {
        const result = await API.graphql(
            graphqlOperation(queries.getProfile, {
                id: "d7031eb6-a54e-411f-a126-1c8ffe57f754",
            })
        );
        console.log(result.data.getProfile);
        console.log("done");
    } catch (err) {
        console.log("error: ", err);
    }
}
var ConnectButton = () => {
    return (
        <TouchableOpacity style={styles.interactButton}>
            <Text style={styles.interactButtonText}>
                <Icon
                    name="handshake-o"
                    type="font-awesome"
                    color="white"
                    size={14}
                />
                &emsp;Connect
            </Text>
        </TouchableOpacity>
    );
};
var MessageButton = () => {
    return (
        <TouchableOpacity
            style={styles.interactButton}

            // style={{
            //     ...styles.interactButton,
            //     backgroundColor: "white",
            //     borderWidth: 2,
            //     borderColor: "#2196f3",
            // }}
        >
            <Text
                style={styles.interactButtonText}
                // style={{
                //     ...styles.interactButtonText,
                //     color: "#2196f3",
                // }}
            >
                <Icon
                    name="comments-o"
                    type="font-awesome"
                    color="white"
                    size={14}
                />
                &emsp;Message
            </Text>
        </TouchableOpacity>
    );
};
// var requestSentButton = () => {return ()};

var ActionButtons = (props) => {
    return (
        <View style={styles.interactButtonsView}>
            {props.num != "1" && <ConnectButton />}
            <MessageButton />
        </View>
    );
};

export function ProfileScreenOld({ navigation, route }) {
    //componentDidMount();
    //getProfilebyID();
    var name = route.params.name;
    var about = route.params.about;
    var img_profile = route.params.img_profile;
    // img_profile = "";
    var conn = 1234; // Supposed to be a list of userids ['1234','23444']
    //console.log("Interests",route.params.interests);
    var interests = ["Tech", "Manufacturing"];

    const [searchText, setSearchText] = useState("");
    const [users, setUsers] = useState([]);
    const [filteredUsers, setFilteredUsers] = useState([]);
    var [modalVisible, toggleModal] = useState(false);

    function renderTags() {
        return interests.map((tag, key) => {
            return (
                <View key={key} style={styles.btnColor}>
                    <Text>{tag}</Text>
                </View>
            );
        });
    }

    return (
        <View style={{ display: "flex", flex: 1, backgroundColor: "#fff" }}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <SearchBar />

                <View style={styles.profileContainer}>
                    {/* Profile Image */}
                    {img_profile ? (
                        <TouchableHighlight
                            underlayColor="none"
                            onPress={() => {
                                toggleModal(true);
                            }}
                        >
                            <Image
                                style={styles.profileImage}
                                source={{
                                    uri: img_profile,
                                }}
                            />
                        </TouchableHighlight>
                    ) : (
                        <View style={styles.profileImage}>
                            <UserAvatar size="200" name={name} />
                        </View>
                    )}
                    {/* Profile Name and Bio */}
                    <View style={styles.nameAndBioView}>
                        <Text style={styles.userFullName}>{name}</Text>
                        <Text style={styles.userBio}>{about}</Text>
                    </View>
                    {/* Posts/Followers/Following View */}
                    <View style={styles.countsView}>
                        <View style={styles.countView}>
                            <Text style={styles.countNum}>13</Text>
                            <Text style={styles.countText}>Businesses</Text>
                        </View>
                        <View style={styles.countView}>
                            <Text style={styles.countNum}>{conn}</Text>
                            <Text style={styles.countText}>Connections</Text>
                        </View>
                    </View>
                    {/* Interact Buttons View */}
                    <ActionButtons num="2" />
                    <Divider />

                    <View style={styles.card}>
                        <Text
                            style={{
                                fontFamily: "Roboto",
                                fontSize: 18,
                                color: "#333",
                                marginLeft: 15,
                            }}
                        >
                            Interests
                        </Text>
                        <View style={[styles.cardContent, styles.tagsContent]}>
                            {renderTags()}
                        </View>
                    </View>
                </View>

                <Modal
                    animationType={"fade"}
                    transparent={false}
                    visible={modalVisible}
                    onRequestClose={() => {
                        toggleModal(false);
                    }}
                >
                    <View style={styles.modal}>
                        <TouchableHighlight
                            underlayColor="none"
                            onPress={() => {
                                toggleModal(false);
                            }}
                        >
                            {/* <Text style={styles.close}>X</Text> */}
                            <Icon
                                style={styles.close}
                                name="close-outline"
                                type="ionicon"
                                color="#fff"
                                size={26}
                            />
                        </TouchableHighlight>
                        <Image
                            style={{
                                width: "100%",
                                height: "100%",
                                resizeMode: "center",
                            }}
                            source={{ uri: img_profile }}
                        />
                    </View>
                </Modal>
            </ScrollView>
        </View>
    );
}
export default class ProfileScreen2 extends Component {
    constructor(props) {
        super(props);

        this.state = {
            name: this.props.route.params.name,
            about: this.props.route.params.about,
            img_profile: this.props.route.params.img_profile,
            interests: ["Tech", "Manufacturing"],
        };
    }
    render() {
        var name = this.state.name;
        var about = this.state.about;
        var img_profile = this.state.img_profile;
        // img_profile = "";
        var conn = 1234; // Supposed to be a list of userids ['1234','23444']
        var interests = this.state.interests;

        function renderTags() {
            return interests.map((tag, key) => {
                return (
                    <View key={key} style={styles.btnColor}>
                        <Text>{tag}</Text>
                    </View>
                );
            });
        }

        return (
            <View style={{ display: "flex", flex: 1, backgroundColor: "#fff" }}>
                <ScrollView showsVerticalScrollIndicator={false}>
                    <SearchBar />

                    <View style={styles.profileContainer}>
                        {/* Profile Image */}
                        {img_profile ? (
                            <Image
                                style={styles.profileImage}
                                source={{
                                    uri: img_profile,
                                }}
                            />
                        ) : (
                            <View style={styles.profileImage}>
                                <UserAvatar size="200" name={name} />
                            </View>
                        )}
                        {/* Profile Name and Bio */}
                        <View style={styles.nameAndBioView}>
                            <Text style={styles.userFullName}>{name}</Text>
                            <Text style={styles.userBio}>{about}</Text>
                        </View>
                        {/* Posts/Followers/Following View */}
                        <View style={styles.countsView}>
                            <View style={styles.countView}>
                                <Text style={styles.countNum}>13</Text>
                                <Text style={styles.countText}>Businesses</Text>
                            </View>
                            <View style={styles.countView}>
                                <Text style={styles.countNum}>{conn}</Text>
                                <Text style={styles.countText}>
                                    Connections
                                </Text>
                            </View>
                        </View>
                        {/* Interact Buttons View */}
                        <ActionButtons num="2" />
                        <Divider />

                        <View style={styles.card}>
                            <Text
                                style={{
                                    fontFamily: "Roboto",
                                    fontSize: 18,
                                    color: "#333",
                                    marginLeft: 15,
                                }}
                            >
                                Interests
                            </Text>
                            <View
                                style={[styles.cardContent, styles.tagsContent]}
                            >
                                {renderTags()}
                            </View>
                        </View>
                    </View>
                </ScrollView>
            </View>
        );
    }
}
const styles = StyleSheet.create({
    coverImage: { height: 300, width: "100%" },
    profileContainer: {
        backgroundColor: "#E0FFFF",
    },
    profileImageView: {
        // backgroundColor: "red",
        zIndex: 1,
        alignSelf: "center",
        marginTop: 50,
        width: 200,
        height: 200,
    },
    profileImage: {
        alignSelf: "center",
        marginTop: 50,
        width: 200,
        height: 200,
        borderRadius: 100,
        // borderWidth: 3,
        // borderColor: "#fff",
    },
    nameAndBioView: { alignItems: "center", marginTop: 10 },
    userFullName: { fontFamily: "Roboto", fontSize: 26 },
    userBio: {
        fontFamily: "Roboto",
        fontSize: 18,
        color: "#333",
        margin: 5,
        textAlign: "center",
    },
    countsView: { flexDirection: "row", marginTop: 20 },
    countView: { flex: 1, alignItems: "center" },
    countNum: { fontFamily: "Roboto", fontSize: 20 },
    countText: { fontFamily: "Roboto", fontSize: 18, color: "#333" },
    interactButtonsView: {
        display: "flex",
        // justifyContent: " space-around",
        flexDirection: "row",
        marginTop: 10,
        padding: 20,
    },
    interactButton: {
        // width: "40%",
        flexGrow: 1,
        // flex: 1,
        flexDirection: "row",
        alignContent: "center",
        justifyContent: "center",
        backgroundColor: "#2196f3",
        margin: 5,
        borderRadius: 4,
    },
    interactButtonText: {
        fontFamily: "Roboto",
        color: "#fff",
        fontSize: 18,
        paddingVertical: 6,
    },
    searchView: {
        display: "flex",
        flexDirection: "row",
    },
    inputView: {
        flex: 1,
        height: 40,
        backgroundColor: "#fff",
        paddingHorizontal: 10,
        borderRadius: 6,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    input: {
        flex: 1,
        height: 40,
        fontSize: 18,
    },
    modal: {
        // flex: 1,
        backgroundColor: "black",
        paddingBottom: 200,
        paddingBottom: 150,
        // justifyContent: "center",
        // padding: 10,
        // alignItems: "flex-end",
    },
    close: {
        // backgroundColor: "aqua",
        // color: "white",
        // fontSize: 20,
        // zIndex: 1,
        // lineHeight: 25,
        fontWeight: "bold",
        // borderColor: "white",
        // borderWidth: 2,
        // margin: 10,
        paddingEnd: 15,
        paddingTop: 15,
        alignSelf: "flex-end",
        // textAlign: "center",
    },
    card: {
        height: null,
        marginTop: 10,
        paddingBottom: 10,
        // backgroundColor: "w",
        flexDirection: "column",
        marginBottom: 20,
    },
    cardContent: {
        flexDirection: "row",
        marginLeft: 10,
    },
    tagsContent: {
        marginTop: 10,
        flexWrap: "wrap",
    },
    btnColor: {
        padding: 10,
        borderRadius: 40,
        marginHorizontal: 3,
        // backgroundColor: '#FAEBD7',
        backgroundColor: "#F5DEB3",
        // backgroundColor: '#87CEFA',
        // backgroundColor: '#90EE90',
        // backgroundColor: '#7FFF00',
        marginTop: 5,
    },
});
