/**================================================================================================
 **        ABOUT
 * @author    : Rishika Bera
 * @createdOn : 03-12-21
 * @modifiedOn : 03-15-21
 * @description : Contains the details of what the project is all about
 *================================================================================================**/

import React, { useState, useEffect } from "react";
import { Button, View, Text, TextInput } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { StyleSheet, Image, ScrollView, Alert } from "react-native";

import { Header } from "react-native-elements";

export default function AboutUs() {
    return (
        <ScrollView>
            <Image
                style={styles.logo}
                source={{
                    uri:
                        "https://yt3.ggpht.com/ytc/AAUvwnjkzB0GlYHYgkViZ9uSeKlfaafTZwz7K2KddKyAsg=s900-c-k-c0x00ffffff-no-rj",
                }}
            />

            <Text style={styles.aboutUsText}>
                Our platform, Startup Canada is beneficial for women
                entrepreneurs who are passionately looking for peer
                entrepreneurs, mentors and investors for networking and
                eventually for the better growth of their business. This
                platform helps connect, chat, look into profiles and also
                schedule appointments.
            </Text>
        </ScrollView>
    );
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 40,
    },
    aboutUsText: {
        alignSelf: "center",
        fontSize: 20,
        fontFamily: "Roboto",
        marginTop: 10,
        color: "black",
        padding: 10,
    },
    logo: {
        alignSelf: "center",
        width: 400,
        height: 400,
        padding: 10,
    },
});
