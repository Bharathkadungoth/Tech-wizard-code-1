/**================================================================================================
 **        ABOUT
 * @authors    : Aditya Bajaj, Rishika Bera, Gayathri Sitaraman
 * @createdOn : 04-15-21
 * @modifiedOn : 04-15-21
 * @description : Contains the Setting Screen components.
 *================================================================================================**/

import React, { Component } from "react";
import { StyleSheet, View, ScrollView } from "react-native";
import { Icon } from "react-native-elements";
import { withNavigation } from "@react-navigation/compat";
import { Button } from "react-native-paper";
import { Divider } from "react-native-paper";
import Amplify, { API, graphqlOperation, Auth } from "aws-amplify";

async function signOut() {
    try {
        const result = await Auth.signOut();
        console.log("Success", result);
    } catch (error) {
        console.log("error signing out: ", error);
    }
    return;
}
class SettingsScreen extends Component {
    render() {
        return (
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ flex: 1, marginBottom: 10, marginTop: 1 }}>
                    <Button
                        style={styles.button}
                        labelStyle={styles.btnLabel}
                        contentStyle={styles.btnContent}
                        icon="logout"
                        mode="contained"
                        onPress={() => {
                            signOut();
                            this.props.navigation.navigate("InitialScreen");

                            //navigate to login screen
                        }}
                    >
                        Logout
                    </Button>
                    <Divider />
                    <Button
                        style={styles.button}
                        labelStyle={styles.btnLabel}
                        contentStyle={styles.btnContent}
                        icon="account-edit"
                        mode="contained"
                        onPress={() =>
                            this.props.navigation.navigate("EditProfile")
                        }
                    >
                        Edit Profile
                    </Button>
                    <Divider />
                    <Button
                        style={styles.button}
                        labelStyle={styles.btnLabel}
                        contentStyle={styles.btnContent}
                        icon="information"
                        mode="contained"
                        onPress={() =>
                            this.props.navigation.navigate("AboutUs")
                        }
                    >
                        About Us
                    </Button>
                </View>
            </ScrollView>
        );
    }
}
export default withNavigation(SettingsScreen);

const styles = StyleSheet.create({
    button: {
        backgroundColor: "white",
        alignContent: "flex-start",
    },
    btnContent: {
        alignSelf: "flex-start",
    },
    btnLabel: { color: "black", textTransform: "none" },
});
