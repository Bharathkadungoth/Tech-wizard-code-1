
//@authors - Gayathri Sitaraman, Swarnalatha Srenigarajan


import React, { Component, useState } from "react";
//import { useNavigation } from '@react-navigation/native';
import AsyncStorage from "@react-native-async-storage/async-storage";

import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    ScrollView,
    TouchableHighlight,
    FlatList,
} from "react-native";
import { Icon } from "react-native-elements";
//import { withNavigation } from 'react-navigation';
import { withNavigation } from "@react-navigation/compat";

/*AWS configs and related statements */
import * as queries from "../../src/graphql/queries";
import * as mutations from "../../src/graphql/mutations";
import * as subscriptions from "../../src/graphql/subscriptions";
import Amplify from "aws-amplify";
import { API, graphqlOperation } from "aws-amplify";
import config from "../../aws-exports";
Amplify.configure(config);

//Amplify.configure(awsconfig);
//export default function ChatScreen({ navigation,
class ChatInvocation extends React.Component {
    constructor(props) {
        super(props);
        //const {navigateto}  = props.navigation;
        var lin = {
            input: {
                activechannelandusers: [
                    "3.Gayathri.8e3e4522-9af3-4d80-bc0d-4df15d60f304",
                    "4.Clare.2bb1f840-6da8-4a4b-a914-ed2e50410664",
                ],
            },
        };
        async function createActiveChannelDummy() {
            console.log("Doing async call");

            try {
                const result = await API.graphql(
                    graphqlOperation(mutations.createUserChannnelData, lin)
                );
                console.log("Success", result);
            } catch (err) {
                console.log("Error in creation", err);
            }
        }

        this.state = {
            otheruserID: "",
            otherusername: "",

            data: [
                {
                    id: 1,
                    image: "https://bootdey.com/img/Content/avatar/avatar2.png",
                    name: "Dev Patel",
                },
                {
                    id: 2,
                    image: "https://bootdey.com/img/Content/avatar/avatar5.png",
                    name: "Leonard Hofstader",
                },
                {
                    id: 3,
                    image: "https://bootdey.com/img/Content/avatar/avatar4.png",
                    name: "Michael Scott",
                    comment: "You should check with Patel regarding this. ",
                },
                {
                    id: 4,
                    image: "https://bootdey.com/img/Content/avatar/avatar3.png",
                    name: "Melloney Campbell",
                    comment: "Hey! Hope you are doing well! ",
                },
            ],
            //	data: []
        };
        var lget = { userid: "" };
        let dlist = [
            {
                id: 3,
                image: "https://bootdey.com/img/Content/avatar/avatar4.png",
                name: "Michael Scott",
                comment: "You should check with Patel regarding this. ",
            },
        ];

        async function getActiveChannels() {
            console.log("In here");
            try {
                var ldata = JSON.parse(
                    await AsyncStorage.getItem("ActiveChannels")
                );
                console.log("ldata", ldata);
                var i = 0;
                for (i = 0; i < ldata.length; i++) {
                    console.log(i);
                    let str1 = ldata[i];
                    let dat1 = str1.split(".");
                    //console.log("Data channelid",dat1[0],"user name",dat1[1],"user id",dat1[2]);
                    let inp = {
                        id: dat1[0],
                        image:
                            "https://bootdey.com/img/Content/avatar/avatar4.png",
                        name: dat1[1],
                        userid: dat1[2],
                        comment: "Hey! Hope you are doing well! ",
                    };
                    dlist.push(inp);
                    //this.state = {data: dlist};
                    //console.log("dlist  ");
                    //this.setState({data: dlist});
                }
            } catch (err) {
                console.log("Error in fetch", err);
            }
        }

        // createActiveChannelDummy();
        getActiveChannels();
        this.state = { data: dlist };

        // const {navigate} = this.props.navigation;
    }

    render() {
        return (
            <ScrollView showsVerticalScrollIndicator={false}>
                <FlatList
                    style={styles.root}
                    data={this.state.data}
                    extraData={this.state}
                    ItemSeparatorComponent={() => {
                        return <View style={styles.separator} />;
                    }}
                    keyExtractor={(item) => {
                        //console.log("id",item.id);
                        return item.id;
                    }}
                    renderItem={(item) => {
                        console.log("item", item.item);
                        const Notification = item.item;
                        return (
                            <TouchableOpacity
                                style={styles.container}
                                onPress={() =>
                                    this.props.navigation.navigate("Chat", {
                                        name: item.item.name,
                                        img_profile:
                                            "https://i.imgur.com/LXn4igs.jpg",
                                        channelid: item.item.id,
                                        userid: item.item.userid,
                                    })
                                }
                            >
                                <View style={styles.content}>
                                    <View style={styles.contentHeader}>
                                        <Text style={styles.name}>
                                            {Notification.name}
                                        </Text>
                                        <Text style={styles.time}>9:58 am</Text>
                                    </View>
                                    <Text rkType="primary3 mediumLine">
                                        {Notification.comment}
                                    </Text>
                                </View>
                            </TouchableOpacity>
                        );
                    }}
                />
                <FlatList
                    enableEmptySections={true}
                    data={this.state.data2}
                    keyExtractor={(item) => {
                        return item.id;
                    }}
                    renderItem={({ item }) => {
                        return (
                            <View style={styles.box}>
                                <Image
                                    style={styles.image2}
                                    source={{ uri: item.image }}
                                />
                                <View style={styles.boxContent}>
                                    <Text style={styles.title}>
                                        {item.title}
                                    </Text>
                                    <Text style={styles.description}>
                                        {item.description}
                                    </Text>
                                    <View style={styles.buttons}>
                                        <TouchableHighlight
                                            style={[styles.button, styles.view]}
                                            onPress={() => console.log("Yes")}
                                        >
                                            <Icon
                                                name="check"
                                                type="font-awesome"
                                                color="#000"
                                                size={20}
                                            />
                                        </TouchableHighlight>

                                        <TouchableHighlight
                                            style={[
                                                styles.button,
                                                styles.profile,
                                            ]}
                                            onPress={() => console.log("No")}
                                        >
                                            <Icon
                                                name="times"
                                                type="font-awesome"
                                                color="#000"
                                                size={20}
                                            />
                                        </TouchableHighlight>

                                        <TouchableHighlight
                                            style={[
                                                styles.button,
                                                styles.message,
                                            ]}
                                            onPress={() =>
                                                console.log(
                                                    "Doesn't fit my schedule"
                                                )
                                            }
                                        >
                                            <Icon
                                                name="calendar-times-o"
                                                type="font-awesome"
                                                color="#000"
                                                size={20}
                                            />
                                        </TouchableHighlight>
                                    </View>
                                </View>
                            </View>
                        );
                    }}
                />
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    root: {
        backgroundColor: "#ffffff",
        marginTop: 10,
    },
    container: {
        paddingLeft: 19,
        paddingRight: 16,
        paddingVertical: 12,
        flexDirection: "row",
        alignItems: "flex-start",
    },
    content: {
        marginLeft: 16,
        flex: 1,
    },
    contentHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 6,
    },
    separator: {
        height: 1,
        backgroundColor: "#CCCCCC",
    },
    image: {
        width: 45,
        height: 45,
        borderRadius: 20,
        marginLeft: 20,
    },
    time: {
        fontSize: 11,
        color: "#808080",
    },
    name: {
        fontSize: 16,
        fontWeight: "bold",
    },
    // ===========================
    image2: {
        width: 70,
        height: 70,
        borderRadius: 20,
    },
    box: {
        padding: 10,
        marginTop: 5,
        marginBottom: 5,
        backgroundColor: "white",
        flexDirection: "row",
    },
    boxContent: {
        flex: 1,
        flexDirection: "column",
        alignItems: "flex-start",
        marginLeft: 10,
    },
    title: {
        fontSize: 15,
        color: "#151515",
    },
    description: {
        fontSize: 12,
        color: "#646464",
    },
    buttons: {
        flexDirection: "row",
    },
    button: {
        height: 30,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 10,
        width: 35,
        marginRight: 5,
        marginTop: 5,
    },
    icon: {
        width: 15,
        height: 15,
    },
    view: {
        // backgroundColor: "#eee",
        backgroundColor: "#7FFF00",
    },
    profile: {
        // backgroundColor: "#1E90FF",
        backgroundColor: "#FF6347",
    },
    message: {
        // backgroundColor: "#228B22",
        backgroundColor: "#FFE4B5",
    },
});

export default withNavigation(ChatInvocation);
