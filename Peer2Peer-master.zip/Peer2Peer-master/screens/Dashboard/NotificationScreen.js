/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj, Swarnalatha Srenigarajan
 * @createdOn : 03-20-21
 * @modifiedOn : 04-15-21
 * @description : Contains the Notifications Screen.
 *================================================================================================**/

import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    Image,
    ScrollView,
    TouchableHighlight,
    FlatList,
} from "react-native";
import { Icon } from "react-native-elements";
import DateTimePicker from "react-native-modal-datetime-picker";
import moment from "moment";

import Amplify from "aws-amplify";
import { API, graphqlOperation } from "aws-amplify";
import config from "../../aws-exports";
import * as queries from "../../src/graphql/queries";
import {
    createNotifications,
    updateNotifications,
} from "../../src/graphql/mutations";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { not } from "react-native-reanimated";

import { respondConnectionRequest } from "./ConnectionFunctions.js";

async function notifs(
    ret,
    message,
    receiver,
    my_account,
    self_message,
    userObject
) {
    if (ret.length == 0) {
        console.log("If 0");
        try {
            await API.graphql(
                graphqlOperation(createNotifications, {
                    input: {
                        receiveruserID: receiver,
                        SenderStatus: message,
                    },
                })
            );
            console.log("Created");
        } catch (err) {
            console.log("error: ", err);
        }
    } else {
        console.log("If not 0");

        try {
            const result = await API.graphql(
                graphqlOperation(queries.getNotifications, {
                    receiveruserID: receiver,
                })
            );
            var notificationList = result.data.getNotifications.SenderStatus;
            console.log("before:", notificationList);
            notificationList = notificationList.filter((e) => e != userObject);
            console.log(notificationList);
            console.log(message);
            notificationList.push(message);

            await API.graphql(
                graphqlOperation(updateNotifications, {
                    input: {
                        receiveruserID: receiver,
                        SenderStatus: notificationList,
                    },
                })
            );
            console.log("Updated");
        } catch (err) {
            console.log(err);
            return [];
        }
    }
    try {
        const result = await API.graphql(
            graphqlOperation(queries.getNotifications, {
                receiveruserID: my_account,
            })
        );
        var notificationList = result.data.getNotifications.SenderStatus;
        notificationList = notificationList.filter((e) => e != userObject);
        console.log(notificationList);

        notificationList.push(self_message);

        await API.graphql(
            graphqlOperation(updateNotifications, {
                input: {
                    receiveruserID: my_account,
                    SenderStatus: notificationList,
                },
            })
        );
        console.log("Updated");
    } catch (err) {
        console.log("error: ", err);
    }
}

/* Push Notif to db */
async function push_notif(
    message,
    receiver,
    my_account,
    self_message,
    userObject
) {
    console.log(message, receiver, my_account, self_message);
    var op = fetchNotifByID(receiver);

    op.then(
        function (ret) {
            console.log(ret);
            notifs(
                ret,
                message,
                receiver,
                my_account,
                self_message,
                userObject
            );
        },
        function (err) {
            console.log(err);
        }
    );
}

/* Fetch Profile information using ID */

async function fetchNotifByID(userid) {
    try {
        const result = await API.graphql(
            graphqlOperation(queries.getNotifications, {
                receiveruserID: userid,
            })
        );
        var notificationList = result.data.getNotifications.SenderStatus;
        return getdata(notificationList, userid);
    } catch (err) {
        console.log(err);
        return [];
    }
}

function getdata(notificationList, userid) {
    var output = [];
    var myUserID = userid;

    for (let userObject of notificationList) {
        var notif = userObject.split(":");
        var name = notif[2];
        var sender_id = notif[1];
        var msg;

        if (notif[3] == "Accepted") {
            msg = {
                id: name,
                type: "accept",
                subtype: "connection",
                image: "https://bootdey.com/img/Content/avatar/avatar8.png",
                name: name,
            };
            output.push(msg);
        } else if (notif[3] == "noAction") {
            msg = {
                id: name,
                type: "request",
                subtype: "connection",
                image: "https://bootdey.com/img/Content/avatar/avatar8.png",
                name: name,
                sender_user_id: sender_id,
                pos_send_message:
                    "from:" + myUserID + ":" + name + ":" + "Accepted",
                neg_send_message:
                    "from:" + myUserID + ":" + name + ":" + "Declined",
                self_Id: myUserID,
                self_message: userObject + "done",
                userObject: userObject,
            };
            output.push(msg);
        }
    }
    //console.log(output);
    return output;
}

/* End of Display notification */

async function getMyId() {
    return await AsyncStorage.getItem("myuserid");
}
export default class NotificationScreen extends Component {
    constructor(props) {
        super(props);
        this.state = {
            isVisible: false,
            chosenDate: "",
            notifs: [
                {
                    id: 2,
                    type: "accept",
                    subtype: "connection",
                    image: "https://bootdey.com/img/Content/avatar/avatar5.png",
                    name: "Leonard Hofstader",
                },
                {
                    id: 4,
                    type: "request",
                    subtype: "connection",
                    name: "Walter White",
                    title: "Walter White has sent a connection request",
                    description: "Hey! Let's connect.",
                    image: "https://bootdey.com/img/Content/avatar/avatar1.png",
                    buttons: 2,
                },
                {
                    id: 7,
                    type: "accept",
                    subtype: "connection",
                    image: "https://bootdey.com/img/Content/avatar/avatar8.png",
                    name: "Hailee Steinfield",
                },
            ],
            myUserID: null,
            data: null,
        };
    }
    componentDidMount() {
        this._asyncRequest = getMyId().then((res) => {
            this.setState({ myUserID: res });

            var op = fetchNotifByID(res);
            var that = this;
            op.then(
                function (result) {
                    that.setState({ data: result });
                },
                function (err) {
                    console.log(err);
                }
            );
        });
    }
    componentDidUpdate() {
        var op;
        setInterval(() => {
            op = fetchNotifByID(this.state.myUserID);
            var that = this;
            op.then(
                function (result) {
                    that.setState({ data: result });
                },
                function (err) {
                    console.log(err);
                }
            );
        }, 5000);
    }
    // handlePicker = (datetime) => {
    //     this.setState({
    //         isVisible: false,
    //         chosenDate: moment(datetime).format("MMMM, Do YYYY HH:mm"),
    //     });
    // };

    showPicker = () => {
        this.setState({
            isVisible: true,
        });
    };
    hidePicker = () => {
        this.setState({
            isVisible: false,
        });
    };

    render() {
        // var myUserID = "044b9c81-f48e-438a-9d69-178cf1ca587c";
        // push_notif(
        //     "from:550307c0-c15d-4dca-849b-675c3133dfde:Heriberto:Declined",
        //     "43b5ca5b-7f90-407c-a61e-605395828472"
        // );

        return (
            <ScrollView showsVerticalScrollIndicator={false}>
                <FlatList
                    style={styles.root}
                    data={this.state.data}
                    extraData={this.state}
                    ItemSeparatorComponent={() => {
                        return <View style={styles.separator} />;
                    }}
                    keyExtractor={(item) => {
                        return item.id;
                    }}
                    renderItem={(item) => {
                        const Notification = item.item;
                        var type = Notification.type;

                        if (type == "accept") {
                            return (
                                <View style={styles.container}>
                                    <View style={styles.content}>
                                        <Text rkType="primary3 mediumLine">
                                            {Notification.name} has accepted
                                            your connection request
                                        </Text>
                                    </View>
                                </View>
                            );
                        } else {
                            return (
                                <View style={styles.box}>
                                    <View style={styles.boxContent}>
                                        <View
                                            style={{
                                                ...styles.content,
                                                flexDirection: "row",
                                                justifyContent: "space-between",
                                                width: "100%",
                                            }}
                                        >
                                            <Text style={styles.title}>
                                                {Notification.name} has sent you
                                                a connection request!
                                            </Text>
                                        </View>

                                        <View style={styles.buttons}>
                                            <TouchableHighlight
                                                style={[
                                                    styles.button,
                                                    styles.yesbtn,
                                                ]}
                                                onPress={
                                                    () =>
                                                        push_notif(
                                                            Notification.pos_send_message,
                                                            Notification.sender_user_id,
                                                            Notification.self_Id,
                                                            Notification.self_message,
                                                            Notification.userObject
                                                        )
                                                    //respondConnectionRequest("Accepted", Notification.sender_user_id,Notification.self_Id );
                                                }
                                            >
                                                <Icon
                                                    name="check"
                                                    type="font-awesome"
                                                    color="#000"
                                                    size={20}
                                                />
                                            </TouchableHighlight>

                                            <TouchableHighlight
                                                style={[
                                                    styles.button,
                                                    styles.nobtn,
                                                ]}
                                                onPress={
                                                    () =>
                                                        push_notif(
                                                            Notification.neg_send_message,
                                                            Notification.sender_user_id,
                                                            Notification.self_Id,
                                                            Notification.self_message,
                                                            Notification.userObject
                                                        )
                                                    //respondConnectionRequest("Declined", Notification.sender_user_id,Notification.self_Id );
                                                }
                                            >
                                                <Icon
                                                    name="times"
                                                    type="font-awesome"
                                                    color="#000"
                                                    size={20}
                                                />
                                            </TouchableHighlight>
                                            <View>
                                                {Notification.subtype ==
                                                    "meeting" && (
                                                    <TouchableOpacity
                                                        style={[
                                                            styles.button,
                                                            styles.message,
                                                        ]}
                                                        onPress={
                                                            this.showPicker
                                                        }
                                                    >
                                                        <Icon
                                                            name="calendar-times-o"
                                                            type="font-awesome"
                                                            color="#000"
                                                            size={20}
                                                        />
                                                    </TouchableOpacity>
                                                )}
                                                <DateTimePicker
                                                    isVisible={
                                                        this.state.isVisible
                                                    }
                                                    onConfirm={
                                                        this.handlePicker
                                                    }
                                                    onCancel={this.hidePicker}
                                                    mode={"datetime"}
                                                    is24hour={true}
                                                    datePickerModeAndroid={
                                                        "spinner"
                                                    }
                                                />
                                            </View>
                                        </View>
                                    </View>
                                </View>
                            );
                        }
                    }}
                />
            </ScrollView>
        );
    }
}

const styles = StyleSheet.create({
    root: {
        backgroundColor: "#ffffff",
    },
    container: {
        paddingLeft: 20,
        paddingRight: 16,
        paddingVertical: 12,
        flexDirection: "row",
        alignItems: "flex-start",
    },
    content: {
        marginLeft: 16,
        flex: 1,
    },
    contentHeader: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginBottom: 6,
    },
    separator: {
        height: 1,
        backgroundColor: "#CCCCCC",
    },
    image: {
        width: 45,
        height: 45,
        borderRadius: 20,
        marginLeft: 20,
    },
    time: {
        alignSelf: "center",
        fontSize: 11,
        color: "#808080",
    },
    name: {
        fontSize: 16,
        fontWeight: "bold",
    },
    // ===========================
    image2: {
        width: 70,
        height: 70,
        borderRadius: 35,
        alignItems: "flex-start",
    },
    box: {
        padding: 10,
        paddingLeft: 20,
        marginBottom: 5,
        backgroundColor: "white",
        flexDirection: "row",
    },
    boxContent: {
        flex: 1,
        flexDirection: "column",
        alignItems: "flex-start",
        marginLeft: 10,
    },
    title: {
        fontSize: 15,
        color: "#151515",
    },
    description: {
        fontSize: 12,
        color: "#646464",
    },
    buttons: {
        flexDirection: "row",
    },
    button: {
        height: 30,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 10,
        width: 35,
        marginRight: 5,
        marginTop: 5,
    },
    icon: {
        width: 15,
        height: 15,
    },
    yesbtn: {
        // backgroundColor: "#eee",
        backgroundColor: "#7FFF00",
    },
    nobtn: {
        // backgroundColor: "#1E90FF",
        backgroundColor: "#FF6347",
    },
    message: {
        // backgroundColor: "#228B22",
        backgroundColor: "#FFE4B5",
    },
});
