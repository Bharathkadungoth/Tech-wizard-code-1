/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj, Prashant Singh, Gayathri Sitaraman, Swarnalatha Srenigarajan
 * @createdOn : 04-15-21
 * @modifiedOn : 04-22-21
 * @description : Contains the components to show user recomendations.
 *================================================================================================**/

import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    Image,
    TouchableOpacity,
    ScrollView,
    StatusBar,
    FlatList,
    SafeAreaView,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { sendConnectionRequest } from "./ConnectionFunctions.js";
import AutoSearch from "./AutoSearch";
import { Header } from "react-native-elements";
import { useNavigation } from "@react-navigation/native";
import { Button } from "react-native-paper";
import { ActivityIndicator } from "react-native-paper";
import AsyncStorage from "@react-native-async-storage/async-storage";

import ProfileButton from "./ProfileButton";
import * as queries from "../../src/graphql/queries";
import * as mutations from "../../src/graphql/mutations";
import * as subscriptions from "../../src/graphql/subscriptions";
import Amplify from "aws-amplify";
import { API, graphqlOperation } from "aws-amplify";
import config from "../../aws-exports";
Amplify.configure(config);

var initial_list_interests = [];
var user_profiles_recommend = [];
var user_profiles_recommend_final = [];
var result_ids = [];
var exclude_profiles = [];

async function getMyId() {
    return await AsyncStorage.getItem("myuserid");
}

async function getBusinessInterests(myID) {
    try {
        listCheck(myID);
        console.log("id is", myID);
        const result = await API.graphql(
            graphqlOperation(queries.getProfile, {
                userid: myID, //use myuserid here
            })
            //550307c0-c15d-4dca-849b-675c3133dfde
        );
        // console.log(result.data.getProfile);
        initial_list_interests.push(result.data.getProfile.business_interests);
        // console.log(initial_list_interests);

        return getProfilesByInterest();
    } catch (err) {
        console.log(err);
    }
}

//Creates list of profiles to be excluded
async function listCheck(myID) {
    try {
        var id = myID;
        const val2 = await AsyncStorage.getItem("ConnectionData");

        const networkDetails = JSON.parse(val2);

        var friends = networkDetails.friends;
        var sentProfiles = networkDetails.sent;
        var receivedProfiles = networkDetails.received;

        //Added Friends, sent requests and received requests to exclusion list
        exclude_profiles = exclude_profiles.concat(friends);
        exclude_profiles = exclude_profiles.concat(sentProfiles);
        exclude_profiles = exclude_profiles.concat(receivedProfiles);
        //added self profile (user gets recommended themselves)
        exclude_profiles.push(id);
    } catch (err) {
        console.log(err);
    }
}

function getUnique(value, index, self) {
    return self.indexOf(value) === index;
}

async function getProfilesByInterest() {
    try {
        for (var i = 0; i < initial_list_interests[0].length; i++) {
            const result = await API.graphql(
                graphqlOperation(queries.getInterestsTable, {
                    interest_name: initial_list_interests[0][i],
                })
            );
            // console.log(result.data.getInterestsTable.user_id_list);
            // console.log("Fetched Profiles by Interest");

            user_profiles_recommend = user_profiles_recommend.concat(
                result.data.getInterestsTable.user_id_list
            );
        }
        return getProfilesByExpertise();
    } catch (err) {
        console.log("error: ", err);
    }
}

async function getProfilesByExpertise() {
    try {
        for (var i = 0; i < initial_list_interests[0].length; i++) {
            const result = await API.graphql(
                graphqlOperation(queries.getExpertiseTable, {
                    domainVal: initial_list_interests[0][i],
                })
            );
            // console.log(result.data.getExpertiseTable.userIDList);
            // console.log("Fetched Profiles by Expertise");

            user_profiles_recommend = user_profiles_recommend.concat(
                result.data.getExpertiseTable.userIDList
            );
        }
        return getRecommendedProfiles();
    } catch (err) {
        console.log("error: ", err);
    }
}

async function getRecommendedProfiles() {
    var temp = [];

    for (var i = 0; i < user_profiles_recommend.length; i++) {
        user_profiles_recommend_final.push(user_profiles_recommend[i]);
    }

    user_profiles_recommend_final = user_profiles_recommend_final.filter(
        function (obj) {
            return exclude_profiles.indexOf(obj) == -1;
        }
    );

    user_profiles_recommend_final = user_profiles_recommend_final.filter(
        getUnique
    );

    try {
        for (var i = 0; i < user_profiles_recommend_final.length; i++) {
            const result = await API.graphql(
                graphqlOperation(queries.getProfile, {
                    userid: user_profiles_recommend_final[i],
                })
            );
            // temp.push(result.data.getProfile.id);
            temp.push([
                result.data.getProfile.id,
                result.data.getProfile.name,
                result.data.getProfile.bio,
            ]);
        }
        return temp;
    } catch (err) {
        console.log("error: ", err);
    }
}

export default class ExploreScreen extends Component {
    state = {
        externalData: null,
        test: 1,
        userid: null,
    };

    componentDidMount() {
        this._asyncRequest = getMyId().then((res) => {
            this.setState({ userid: res });

            var rec = getBusinessInterests(res);
            var that = this;
            rec.then(
                function (result) {
                    that.setState({ externalData: result });
                    console.log("result is", result);
                },
                function (err) {
                    console.log(err); // Error: "It broke"
                }
            );
        });
    }

    componentWillUnmount() {}

    render() {
        const conn = (
            <Button
                style={styles.followButton}
                mode="contained"
                onPress={() => {
                    console.log("pressed", item[0]);
                }}
            >
                Connect
            </Button>
        );
        return (
            <LinearGradient
                colors={["#090979", "#00d4ff"]}
                style={styles.container}
            >
                <ScrollView style={{ ...styles.container }}>
                    <Header
                        placement="left"
                        leftComponent={{
                            text: "Explore",
                            style: { color: "#000", fontSize: 20 },
                        }}
                        rightComponent={<ProfileButton />}
                        containerStyle={{
                            backgroundColor: "wheat",
                        }}
                    />
                    <AutoSearch />
                    {this.state.externalData === null ? (
                        <View style={{ height: "400%" }}>
                            <ActivityIndicator
                                style={{ flex: 1 }}
                                animating={true}
                                color="green"
                            />
                        </View>
                    ) : (
                        <FlatList
                            style={styles.list}
                            contentContainerStyle={styles.listContainer}
                            data={this.state.externalData}
                            numColumns={2}
                            keyExtractor={(item) => {
                                return item[0];
                            }}
                            renderItem={({ item }) => {
                                return (
                                    <View style={styles.card}>
                                        <View style={styles.cardFooter}>
                                            <View
                                                style={{
                                                    alignItems: "center",
                                                    justifyContent: "center",
                                                }}
                                            >
                                                <Text style={styles.name}>
                                                    {item[1]}
                                                </Text>
                                                <Text style={styles.bio}>
                                                    {item[2]}
                                                </Text>
                                                <TouchableOpacity
                                                    style={styles.followButton}
                                                    onPress={() => {
                                                        console.log(
                                                            "Pressed",
                                                            item[0]
                                                        );
                                                        sendConnectionRequest(
                                                            item[0]
                                                        );
                                                    }}
                                                >
                                                    <Text
                                                        style={
                                                            styles.followButtonText
                                                        }
                                                    >
                                                        Connect
                                                    </Text>
                                                </TouchableOpacity>
                                            </View>
                                        </View>
                                    </View>
                                );
                            }}
                        />
                    )}
                </ScrollView>
            </LinearGradient>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#1f1f1f",
    },
    userProfileImage: {
        width: 35,
        height: 35,
        borderRadius: 100,
    },
    item: {
        backgroundColor: "#f9c2ff",
        padding: 10,
        marginVertical: 8,
        marginHorizontal: 16,
    },
    title: {
        fontSize: 24,
    },
    card: {
        backgroundColor: "wheat",
        margin: 5,
        flex: 1,
    },
    cardFooter: {
        paddingVertical: 17,
        paddingHorizontal: 16,
        borderTopLeftRadius: 1,
        borderTopRightRadius: 1,
    },
    name: {
        fontSize: 18,
        flex: 1,
        alignSelf: "center",
        color: "#008080",
        fontWeight: "bold",
    },
    bio: {
        fontSize: 14,
        flex: 1,
        alignSelf: "center",
        color: "#696969",
        textAlign: "center",
    },
    followButton: {
        marginTop: 10,
        height: 35,
        width: 80,
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        borderRadius: 30,
        backgroundColor: "#00BFFF",
    },
    followButtonText: {
        color: "#FFFFFF",
        fontSize: 15,
    },
});
