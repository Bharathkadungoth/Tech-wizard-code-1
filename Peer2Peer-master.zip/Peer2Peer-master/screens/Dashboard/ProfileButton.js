import React, { Component } from "react";
import { withNavigation } from "@react-navigation/compat";
import { StyleSheet, View, Image, TouchableOpacity } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

async function getMyId() {
    return await AsyncStorage.getItem("myuserid");
}

class ProfileButton extends Component {
    state = {
        userid: null,
    };

    componentDidMount() {
        this._asyncRequest = getMyId().then((res) => {
            this.setState({ userid: res });
        });
    }

    render() {
        return (
            <TouchableOpacity
                onPress={() =>
                    this.props.navigation.navigate("Profile", {
                        userid: this.state.userid,
                    })
                }
            >
                <Image
                    style={styles.userProfileImage}
                    source={require("../unnamed.png")}
                />
            </TouchableOpacity>
        );
    }
}
export default withNavigation(ProfileButton);

const styles = StyleSheet.create({
    userProfileImage: {
        width: 35,
        height: 35,
        borderRadius: 100,
    },
});
