// Author : Gayathri Sitaraman



import AsyncStorage from '@react-native-async-storage/async-storage';


import * as queries from "../../src/graphql/queries";
import * as mutations from "../../src/graphql/mutations";
import * as subscriptions from "../../src/graphql/subscriptions";
import Amplify from "aws-amplify";
import { API, graphqlOperation } from "aws-amplify";
import config from "../../aws-exports";
Amplify.configure(config);


import {push_notif, fetchNotifByID} from "./NotificationScreen.js";

export async function sendConnectionRequest(otheruserid) {
	// get details of myuser
	// get details of other user
	//update sent of myuser
	//update received of other user
	console.log("yesss",otheruserid);
	const myuserid = await AsyncStorage.getItem("myuserid");
	const myuserdata = JSON.parse(await AsyncStorage.getItem("Userdata"));
	var mydata = "";
	try {
        const result = await API.graphql(
            graphqlOperation(queries.getConnectionsTable, {
                userID: myuserid
            })
        );
		
        mydata = result.data.getConnectionsTable;
		if(mydata != null){
		mydata.sent.push(otheruserid);
		 
		//Updating sent of myuserid
		await API.graphql(
                    graphqlOperation(mutations.updateConnectionsTable, {
                        input: {
                            userID: myuserid,
                            friends: mydata.friends,
							sent: mydata.sent,
							received: mydata.received
                        },
                    })
                );
		await AsyncStorage.setItem("ConnectionData",JSON.stringify(mydata));
		}
		
		else 
		{
			await API.graphql(
                    graphqlOperation(mutations.createConnectionsTable, {
                        input: {
                            userID: myuserid,
                            friends: [],
							sent: [otheruserid],
							received: []
                        },
                    })
                );
		await AsyncStorage.setItem("ConnectionData",JSON.stringify( {
                            userID: myuserid,
                            friends: [],
							sent: [otheruserid],
							received: []
                        }));
		}
		
		
		
		/* Updating otheruserid received list */
		const result2 = await API.graphql(
            graphqlOperation(queries.getConnectionsTable, {
                userID: otheruserid
            })
        );
        const otherdata = result2.data.getConnectionsTable;
		
		if(otherdata != null) {
		otherdata.received.push(myuserid);
		 
		//Updating sent of myuserid
		await API.graphql(
                    graphqlOperation(mutations.updateConnectionsTable, {
                        input: {
                            userID: otheruserid,
                            friends: otherdata.friends,
							sent: otherdata.sent,
							received: otherdata.received
                        }
                    })
                );
		}
		else {
			await API.graphql(
                    graphqlOperation(mutations.createConnectionsTable, {
                        input: {
                            userID: otheruserid,
                            friends: [],
							received: [myuserid],
							sent: []
                        },
                    })
                );
			
		}
		
		
		/*Updating notification of otheruser */
		var message = "from:" + myuserid + ":" + myuserdata.name + ":" + "noAction";
		console.log("Message",message,"Receiver",otheruserid);
		push_notif(message,otheruserid,myuserid,"","nothing");
    } catch (err) {
        console.log("error: ", err);
    }
	
	
	
}

//import {respondConnectionRequest} from "./ConnectionFunctions.js";

export async function respondConnectionRequest(state, otheruserid, myuserid) {
	
	/* if accepted add to friends list of myuserid and otheruserid */
	var mydata = JSON.parse(await AsyncStorage.getItem("ConnectionData"));
	console.log("State",state,"Receiver",otheruserid);
	var otherdata = "";
	var result = "";
	try{
			result = await API.graphql(
            graphqlOperation(queries.getConnectionsTable, {
                userID: otheruserid
            })
        );
	otherdata = result.data.getConnectionsTable;
	}catch(err) {console.log(err);}
	mydata.received = (mydata.received).filter(e => e != otheruserid); //removed sender id from Received list
	
	otherdata.sent = (otherdata.sent).filter(e => e != myuserid);
	if(state == "Accepted") {
		console.log("Accepted");
		mydata.friends.push(otheruserid);
		otherdata.friends.push(myuserid);
		try {
			await API.graphql(
                    graphqlOperation(mutations.updateConnectionsTable, {
                        input: {
                           				 userID: otheruserid,
                            				friends: otherdata.friends,
							sent: otherdata.sent,
							received: otherdata.received
                        }
                    })
                );
			await API.graphql(
                    graphqlOperation(mutations.updateConnectionsTable, {
                        input: {
                            				userID: myuserid,
                            				friends: mydata.friends,
							sent: mydata.sent,
							received: mydata.received
                        }
                    })
                );
				await AsyncStorage.setItem("ConnectionData",JSON.stringify( {
                            				userID: myuserid,
                            				friends: mydata.friends,
							sent: mydata.sent,
							received: mydata.received
                        }));
			
		}catch(err) {console.log(err);}
	}
}
