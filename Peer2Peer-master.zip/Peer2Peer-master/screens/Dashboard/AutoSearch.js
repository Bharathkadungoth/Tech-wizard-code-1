//code inspired from https://www.npmjs.com/package/react-native-autocomplete-input which is a react native open source library


/*
*  Authors- Swarnalatha Srenigarajan, Gayathri Sitaraman
*
*
*/


import Autocomplete from "react-native-autocomplete-input";
import PropTypes from "prop-types";
import React, { Component, useEffect, useState } from "react";
import {
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
    Platform,
} from "react-native";
import { Card, ListItem, Button, Icon } from "react-native-elements";
import { Constants } from "expo";
import { useNavigation } from "@react-navigation/native";

import * as queries from "../../src/graphql/queries";
import * as mutations from "../../src/graphql/mutations";
import * as subscriptions from "../../src/graphql/subscriptions";
import Amplify from "aws-amplify";
import { API, graphqlOperation } from "aws-amplify";
import config from "../../aws-exports";
Amplify.configure(config);

var user;
async function Profiles() {
    try {
        const profiles = await API.graphql(
            graphqlOperation(queries.listProfiles)
        );
        user = profiles.data.listProfiles.items;
        // console.log(profiles.data.listProfiles.items);
    } catch (err) {
        console.log("error: ", err);
    }
}
async function getSelectedProfile(userID) {
    try {
        const result = await API.graphql(
            graphqlOperation(queries.getProfile, {
                userid: userID,
            })
        );
        const userinfo = result.data.getProfile;
        // console.log("userdata", userinfo);
        return userinfo;

        console.log("done");
    } catch (err) {
        console.log("error: ", err);
    }
}

function comp(a, b) {
    return a.toLowerCase().trim() === b.toLowerCase().trim();
}

function findUser(query, users) {
    if (query === "") {
        return [];
    }

    const regex = new RegExp(`${query.trim()}`, "i");
    return user.filter((profiles) => profiles.name.search(regex) >= 0);
}

const AutoSearch = () => {
    const [allUsers, setAllUsers] = useState([]);
    const [query, setQuery] = useState("");
    const users = findUser(query, allUsers);
    useEffect(() => {
        Profiles();
        setAllUsers(user);
    }, []);

    const options = [
        {
            key: "Mentor",
            text: "Mentor",
        },
        {
            key: "Mentee",
            text: "Mentee",
        },
        {
            key: "Investor",
            text: "Investor",
        },
    ];

    const onSelect = (item) => {
        if (selectedOption && selectedOption.key === item.key) {
            setSelectedOption(null);
        } else {
            setSelectedOption(item);
        }
    };

    const onSubmit = () => {
        console.log(selectedOption);
    };

    const [selectedOption, setSelectedOption] = React.useState(null);

    const navigation = useNavigation();
    return (
        <View style={styles.container}>
            <View style={styles.autocompleteContainer}>
                <Autocomplete
                    autoCapitalize="none"
                    autoCorrect={false}
                    data={
                        users.length === 1 && comp(query, users[0].name)
                            ? []
                            : users
                    }
                    value={query}
                    onChangeText={setQuery}
                    placeholder="Search"
                    flatListProps={{
                        keyExtractor: (item) => item.name,
                        renderItem: ({ item, i }) => (
                            <TouchableOpacity
                                onPress={() =>
                                    /*setQuery(item.name)*/
                                    {
                                        console.log(
                                            "Userid pressed => ",
                                            item.userid
                                        );
                                        const userinfo = getSelectedProfile(
                                            item.userid
                                        );
                                        // console.log("Navi to ", item.userid);
                                        navigation.navigate("Profile", {
                                            userid: item.userid,
                                        });
                                    }
                                }
                            >
                                <Text style={styles.baseText}>
                                    {item.name}
                                    {"\t"}
                                    <Text style={styles.innerText}>
                                        {"Role : "}
                                        {item.role}
                                    </Text>
                                </Text>
                            </TouchableOpacity>
                        ),
                    }}
                />
            </View>

            {/* <View style={styles.radioContainer}>
        <RadioButton
          selectedOption={selectedOption}
          onSelect={onSelect}
          options={options}
        />
        <Button title="SUBMIT" onPress={onSubmit} /> */}
            {/* </View> */}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        position: "relative",
        backgroundColor: "#F5FCFF",
        flex: 1,

        // Android requiers padding to avoid overlapping
        // with content and autocomplete
        paddingTop: 50,
        zIndex: 1,
        // Make space for the default top bar
        ...Platform.select({
            web: {
                marginTop: 0,
            },
            default: {
                marginTop: 25,
            },
        }),
    },

    radioContainer: {
        flex: 1,
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
    },

    itemText: {
        fontSize: 15,
        margin: 2,
    },
    descriptionContainer: {
        // `backgroundColor` needs to be set otherwise the
        // autocomplete input will disappear on text input.
        backgroundColor: "#F5FCFF",
        marginTop: 8,
    },
    infoText: {
        textAlign: "center",
    },
    titleText: {
        fontSize: 18,
        fontWeight: "500",
        marginBottom: 10,
        marginTop: 10,
        textAlign: "center",
    },
    directorText: {
        color: "grey",
        fontSize: 12,
        marginBottom: 10,
        textAlign: "center",
    },
    openingText: {
        textAlign: "center",
    },
    autocompleteContainer: {
        // Hack required to make the autocomplete
        // work on Andrdoid
        flex: 1,
        left: 0,
        position: "absolute",
        right: 0,
        top: 0,
        zIndex: 1,
        padding: 5,
    },
    baseText: {
        fontWeight: "bold",
        fontFamily: "Cochin",
    },
    innerText: {
        color: "gray",
        fontFamily: "Cochin",
    },
});

export default AutoSearch;
