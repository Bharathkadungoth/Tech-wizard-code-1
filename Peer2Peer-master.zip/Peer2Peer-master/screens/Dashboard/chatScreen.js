/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj, Gayathri Sitaraman
 * @createdOn : 03-20-21
 * @modifiedOn : 03-22-21
 * @description : Contains the components that load the chat screen.
 *================================================================================================**/

import React, { useState, useEffect } from "react";
import { Button, View, Text, TextInput } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import {
    StyleSheet,
    Image,
    TouchableOpacity,
    TouchableWithoutFeedback,
    Keyboard,
    ScrollView,
    FlatList,
    Dimensions,
    Alert,
} from "react-native";
import { Icon } from "react-native-elements";

import AsyncStorage from "@react-native-async-storage/async-storage";

/*AWS configs and related statements */
//import * as queries from '../src/graphql/queries.js';
import Amplify from "@aws-amplify/core";
import API, { graphqlOperation } from "@aws-amplify/api";
import "@aws-amplify/pubsub";

import * as mutations from "../../src/graphql/mutations";
//import * as subscriptions from '../src/graphql/subscriptions';
//import * as queries from '../src/graphql/queries';
import { onCreateMessage } from "../../src/graphql/subscriptions";
import { messagesByChannelID } from "../../src/graphql/queries";

import awsExports from "../../aws-exports";

Amplify.configure(awsExports);

async function getMyuserdata() {
    try {
        return JSON.parse(data);
    } catch (err) {
        console.log(err);
    }
}
export default function ChatScreen({ navigation, route }) {
    const [messageBody, setMessageBody] = useState("");
    const [messages, setMessages] = useState([]);
    const [chatUser] = useState({
        name: route.params.name,
        profile_image: "https://i.imgur.com/AaThbvA.jpg",
        profile_image: route.params.img_profile,
        last_seen: "online",
        channelID: route.params.channelid,
    });

    const [currentUser] = useState({
        name: "",
        channelidstr: route.params.channelid,
    });

    useEffect(() => {
        API.graphql(
            graphqlOperation(messagesByChannelID, {
                channelID: currentUser.channelidstr,
                sortDirection: "ASC",
            })
        ).then((response) => {
            const items = response?.data?.messagesByChannelID?.items;

            if (items) {
                setMessages(items);
            }
        });
    }, []);

    useEffect(() => {
        const subscription = API.graphql(
            graphqlOperation(onCreateMessage, {
                channelID: currentUser.channelidstr,
            })
        ).subscribe({
            next: (event) => {
                console.log("Maybe", event);
                setMessages([...messages, event.value.data.onCreateMessage]);
            },
        });

        return () => {
            subscription.unsubscribe();
        };
    }, [messages]);

    const handleChange = (event) => {
        setMessageBody(event.target.value);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        event.stopPropagation();
        const myuserdata = JSON.parse(await AsyncStorage.getItem("Userdata"));
        console.log("data", myuserdata);
        currentUser.name = myuserdata.name;
        const inputdata = {
            channelID: currentUser.channelidstr,
            author: currentUser.name,
            body: messageBody.trim(),
        };

        try {
            console.log("Sending", inputdata);
            setMessageBody("");
            await API.graphql(
                graphqlOperation(mutations.createMessage, { input: inputdata })
            );
            console.log("Success");
        } catch (error) {
            console.warn(error);
        }
    };

    /* const handleMonica = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    const input = {
      channelID: '1',
      author: 'Monica',
      body: "hello there ......"
    };
    try {
      setMessageBody('');
      const result = await API.graphql(graphqlOperation(mutations.createMessage, { input }))
	  console.log("Success now wait for results  ", result);
    } catch (error) {
      console.warn(error);
    }
  };*/

    function getTime(date) {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? "PM" : "AM";
        hours = hours % 12;
        hours = hours ? hours : 12;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        var strTime = hours + ":" + minutes + " " + ampm;
        return strTime;
    }

    function sendMessage() {
        if (inputMessage === "") {
            return setInputMessage("");
        }
        let t = getTime(new Date());

        setMessages([
            ...messages,
            {
                author: currentUser.name,
                message: inputMessage,
                time: t,
            },
        ]);
        setInputMessage("");
    }

    React.useEffect(() => {
        navigation.setOptions({
            title: "",
            headerLeft: () => (
                <View style={styles.headerLeft}>
                    <TouchableOpacity
                        style={{ paddingRight: 10 }}
                        onPress={() => {
                            navigation.goBack();
                        }}
                    >
                        <Icon
                            name="angle-left"
                            type="font-awesome"
                            size={30}
                            color="black"
                        />
                    </TouchableOpacity>
                    <Image
                        style={styles.userProfileImage}
                        source={{ uri: chatUser.profile_image }}
                    />
                    <View
                        style={{
                            paddingLeft: 10,
                            justifyContent: "center",
                        }}
                    >
                        <Text
                            style={{
                                color: "black",
                                fontWeight: "700",
                                fontSize: 18,
                            }}
                        >
                            {chatUser.name}
                        </Text>
                        <Text style={{ color: "black", fontWeight: "300" }}>
                            {chatUser.last_seen}
                        </Text>
                    </View>
                </View>
            ),
            headerRight: () => (
                <TouchableOpacity
                    style={{ paddingRight: 10 }}
                    onPress={() => {
                        Alert.alert("Audio Call", "Audio Call Button Pressed");
                    }}
                >
                    <Icon name="call" size={28} color="red" />
                </TouchableOpacity>
            ),
        });
    }, []);

    /*load messages */

    return (
        <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
            <View style={styles.container}>
                <FlatList
                    style={{ backgroundColor: "#f2f2ff" }}
                    inverted={true}
                    data={JSON.parse(JSON.stringify(messages)).reverse()}
                    renderItem={({ item }) => (
                        <TouchableWithoutFeedback>
                            <View style={{ marginTop: 6 }}>
                                <View
                                    style={{
                                        maxWidth:
                                            Dimensions.get("screen").width *
                                            0.8,
                                        backgroundColor: "#3a6ee8",
                                        alignSelf:
                                            item.author === currentUser.name
                                                ? "flex-end"
                                                : "flex-start",
                                        marginHorizontal: 10,
                                        padding: 10,
                                        borderRadius: 8,
                                        borderBottomLeftRadius:
                                            item.author === currentUser.name
                                                ? 8
                                                : 0,
                                        borderBottomRightRadius:
                                            item.author === currentUser.name
                                                ? 0
                                                : 8,
                                    }}
                                >
                                    <Text
                                        style={{
                                            color: "#fff",
                                            fontSize: 16,
                                        }}
                                    >
                                        {item.body}
                                    </Text>
                                    <Text
                                        style={{
                                            color: "#dfe4ea",
                                            fontSize: 14,
                                            alignSelf: "flex-end",
                                        }}
                                    >
                                        {item.createdAt}
                                    </Text>
                                </View>
                            </View>
                        </TouchableWithoutFeedback>
                    )}
                />

                <View style={{ paddingVertical: 10 }}>
                    <View style={styles.messageInputView}>
                        <TextInput
                            defaultValue={messageBody}
                            style={styles.messageInput}
                            placeholder="Message"
                            onChangeText={(text) => setMessageBody(text)}
                            onSubmitEditing={handleSubmit}
                        />
                        <TouchableOpacity
                            style={styles.messageSendView}
                            onPress={handleSubmit}
                        >
                            <Icon name="send" type="material" />
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </TouchableWithoutFeedback>
    );
}
const styles = StyleSheet.create({
    headerLeft: {
        paddingVertical: 4,
        paddingHorizontal: 10,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    userProfileImage: {
        paddingLeft: 20,
        height: "90%",
        aspectRatio: 1,
        borderRadius: 100,
    },
    container: {
        flex: 1,
        backgroundColor: "#f2f2ff",
    },
    messageInputView: {
        display: "flex",
        flexDirection: "row",
        marginHorizontal: 14,
        backgroundColor: "#fff",
        borderRadius: 4,
    },
    messageInput: {
        height: 40,
        flex: 1,
        paddingHorizontal: 10,
    },
    messageSendView: {
        paddingHorizontal: 10,
        justifyContent: "center",
    },
});

/*useEffect(() => {
    API
    .graphql(graphqlOperation(queries.listMessages))
    .then((response) => {
      const items = response.data?.listMessages?.items;
      
      if (items) {
		 console.log(items);
        setMessages(items);
      }
    });
}, []);*/
