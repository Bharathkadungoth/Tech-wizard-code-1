/*================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj, Swarnalatha Srenigarajan
 * @createdOn : 04-15-21
 * @modifiedOn : 04-20-21
 * @description : Contains the Profile Screen components.
 *================================================================================================**/

import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    ScrollView,
    TouchableOpacity,
    Image,
} from "react-native";

import { sendConnectionRequest } from "./ConnectionFunctions.js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Icon } from "react-native-elements";
import Lightbox from "react-native-lightbox";
import { Header } from "react-native-elements";
import { LinearGradient } from "expo-linear-gradient";

import UserAvatar from "react-native-user-avatar";
import { Divider } from "react-native-paper";
import * as queries from "../../src/graphql/queries";
import { withNavigation } from "@react-navigation/compat";
import Amplify from "aws-amplify";
import { API, graphqlOperation } from "aws-amplify";
import config from "../../aws-exports";
Amplify.configure(config);

var network;

async function getMyId() {
    return await AsyncStorage.getItem("myuserid");
}

async function getProfile(id) {
    const result = await API.graphql(
        graphqlOperation(queries.getProfile, {
            userid: id, //use myuserid here
        })
        //550307c0-c15d-4dca-849b-675c3133dfde
    );
    console.log(result.data.getProfile);
    return [
        result.data.getProfile.name,
        result.data.getProfile.bio,
        result.data.getProfile.connections,
        result.data.getProfile.business_interests,
    ];
}
async function checkIfFriend(myUserID, otherUserID) {
    try {
        // console.log("my ID is", myUserID);
        // console.log("other ID is", otherUserID);

        if (myUserID == otherUserID) {
            return 0;
        }

        const result = await API.graphql(
            graphqlOperation(queries.getConnectionsTable, { userID: myUserID })
        );
        network = result.data.getConnectionsTable.friends;
        for (let userObject of network) {
            if (otherUserID === userObject) {
                console.log("Already friends");
                return 1;
            }
        }
        return 2;
    } catch (err) {
        console.log("error: ", err);
    }
}

var ConnectButton = (props) => {
    console.log("Button connect", props);
    return (
        <TouchableOpacity
            style={styles.interactButton}
            onPress={() => {
                sendConnectionRequest(props.otherid);
            }}
        >
            <Text style={styles.interactButtonText}>
                <Icon
                    name="handshake-o"
                    type="font-awesome"
                    color="white"
                    size={14}
                />
                &emsp;Connect
            </Text>
        </TouchableOpacity>
    );
};
var MessageButton = () => {
    return (
        <TouchableOpacity
            style={styles.interactButton}

            // style={{
            //     ...styles.interactButton,
            //     backgroundColor: "white",
            //     borderWidth: 2,
            //     borderColor: "#2196f3",
            // }}
        >
            <Text
                style={styles.interactButtonText}
                // style={{
                //     ...styles.interactButtonText,
                //     color: "#2196f3",
                // }}
            >
                <Icon
                    name="comments-o"
                    type="font-awesome"
                    color="white"
                    size={14}
                />
                &emsp;Message
            </Text>
        </TouchableOpacity>
    );
};
// var requestSentButton = () => {return ()};

var ActionButtons = (props) => {
    return (
        <View style={styles.interactButtonsView}>
            {props.num == "2" && (
                <ConnectButton otherid={props.statevar.otherUserID} />
            )}
            {props.num > 0 && <MessageButton />}
        </View>
    );
};

class ProfileScreen extends Component {
    state = {
        externalData: null,
        btns: null,
        otherUserID: null,
        myUserID: null,
        name: null,
        about: null,
        conn: null,
        interests: null,
    };

    componentDidMount() {
        var otherUserID = this.props.navigation.state.params.userid;

        this._asyncRequest = getMyId().then((res) => {
            this.setState({ myUserID: res });
            this.setState({ otherUserID: otherUserID });

            var btns = checkIfFriend(res, otherUserID);
            var that = this;
            btns.then(
                function (result) {
                    that.setState({ btns: result });
                },
                function (err) {
                    console.log(err);
                }
            );
        });
        this._asyncRequest = getProfile(otherUserID).then((res) => {
            this.setState({ name: res[0] });
            this.setState({ about: res[1] });
            this.setState({ conn: res[2] });
            this.setState({ interests: res[3] });
        });
    }
    componentDidUpdate() {
        var newuser = this.props.navigation.state.params.userid;
        console.log("new user is ", newuser);

        if (
            newuser !== this.state.otherUserID &&
            this.state.otherUserID != null
        ) {
            this._asyncRequest = getProfile(newuser).then((res) => {
                this.setState({ name: res[0] });
                this.setState({ about: res[1] });
                this.setState({ conn: res[2] });
                this.setState({ interests: res[3] });
            });
            var btns = checkIfFriend(this.state.myUserID, newuser);
            var that = this;
            that.setState({ otherUserID: newuser });

            btns.then(
                function (result) {
                    that.setState({ btns: result });
                },
                function (err) {
                    console.log(err); // Error: "It broke"
                }
            );
        }
    }

    componentWillUnmount() {
       /* if (this._asyncRequest) {
            this._asyncRequest.cancel();
        }*/
    }

    render() {
        var name = this.state.name;
        var about = this.state.about;
        var img_profile = "https://i.imgur.com/LXn4igs.jpg";
        var conn = this.state.conn;
        var interests = this.state.interests;

        function renderTags() {
            if (interests) {
                return interests.map((tag, key) => {
                    return (
                        <View key={key} style={styles.btnColor}>
                            <Text>{tag}</Text>
                        </View>
                    );
                });
            }
        }

        return (
            <View style={{ display: "flex", flex: 1, backgroundColor: "#fff" }}>
                <Header
                    placement="left"
                    leftComponent={{
                        text: "Profile",
                        style: { color: "#000", fontSize: 20 },
                    }}
                    containerStyle={{
                        backgroundColor: "wheat",
                    }}
                />
                <LinearGradient
                    colors={["#090979", "#00d4ff"]}
                    style={styles.container}
                >
                    <ScrollView showsVerticalScrollIndicator={false}>
                        <View style={styles.profileContainer}>
                            {img_profile ? (
                                <Image
                                    style={styles.profileImage}
                                    // source={require("../newUser.png")}
                                    // source={require("../default-user.jpg")}
                                    source={require("../unnamed.png")}
                                />
                            ) : (
                                <View style={styles.profileImage}>
                                    <UserAvatar size="200" name={name} />
                                </View>
                            )}
                            {/* Profile Name and Bio */}
                            <View style={styles.nameAndBioView}>
                                <Text style={styles.userFullName}>{name}</Text>
                                <Text style={styles.userBio}>{about}</Text>
                            </View>
                            {/* Posts/Followers/Following View */}
                            <View style={styles.countsView}>
                                <View style={styles.countView}>
                                    <Text style={styles.countNum}>{conn}</Text>
                                    <Text style={styles.countText}>
                                        Connections
                                    </Text>
                                </View>
                            </View>
                            {/* Interact Buttons View */}
                            <ActionButtons
                                num={this.state.btns}
                                statevar={this.state}
                            />
                            <Divider />

                            <View style={styles.card}>
                                <Text
                                    style={{
                                        fontFamily: "Roboto",
                                        fontSize: 18,
                                        color: "#333",
                                        marginLeft: 15,
                                    }}
                                >
                                    Interests
                                </Text>
                                <View
                                    style={[
                                        styles.cardContent,
                                        styles.tagsContent,
                                    ]}
                                >
                                    {renderTags()}
                                </View>
                            </View>
                        </View>
                    </ScrollView>
                </LinearGradient>
            </View>
        );
    }
}
export default withNavigation(ProfileScreen);

const styles = StyleSheet.create({
    coverImage: { height: 300, width: "100%" },
    profileContainer: {
        backgroundColor: "#E0FFFF",
    },
    profileImageView: {
        // backgroundColor: "red",
        zIndex: 1,
        alignSelf: "center",
        marginTop: 50,
        width: 200,
        height: 200,
    },
    profileImage: {
        alignSelf: "center",
        marginTop: 50,
        width: 200,
        height: 200,
        borderRadius: 100,
        // borderWidth: 3,
        // borderColor: "#fff",
    },
    nameAndBioView: { alignItems: "center", marginTop: 10 },
    userFullName: { fontFamily: "Roboto", fontSize: 26 },
    userBio: {
        fontFamily: "Roboto",
        fontSize: 18,
        color: "#333",
        margin: 5,
        textAlign: "center",
    },
    countsView: { flexDirection: "row", marginTop: 20 },
    countView: { flex: 1, alignItems: "center" },
    countNum: { fontFamily: "Roboto", fontSize: 20 },
    countText: { fontFamily: "Roboto", fontSize: 18, color: "#333" },
    interactButtonsView: {
        display: "flex",
        // justifyContent: " space-around",
        flexDirection: "row",
        marginTop: 10,
        padding: 20,
    },
    interactButton: {
        // width: "40%",
        flexGrow: 1,
        // flex: 1,
        flexDirection: "row",
        alignContent: "center",
        justifyContent: "center",
        backgroundColor: "#2196f3",
        margin: 5,
        borderRadius: 4,
    },
    interactButtonText: {
        fontFamily: "Roboto",
        color: "#fff",
        fontSize: 18,
        paddingVertical: 6,
    },
    searchView: {
        display: "flex",
        flexDirection: "row",
    },
    inputView: {
        flex: 1,
        height: 40,
        backgroundColor: "#fff",
        paddingHorizontal: 10,
        borderRadius: 6,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    input: {
        flex: 1,
        height: 40,
        fontSize: 18,
    },
    modal: {
        // flex: 1,
        backgroundColor: "black",
        paddingBottom: 200,
        paddingBottom: 150,
        // justifyContent: "center",
        // padding: 10,
        // alignItems: "flex-end",
    },
    close: {
        // backgroundColor: "aqua",
        // color: "white",
        // fontSize: 20,
        // zIndex: 1,
        // lineHeight: 25,
        fontWeight: "bold",
        // borderColor: "white",
        // borderWidth: 2,
        // margin: 10,
        paddingEnd: 15,
        paddingTop: 15,
        alignSelf: "flex-end",
        // textAlign: "center",
    },
    card: {
        height: null,
        marginTop: 10,
        paddingBottom: 10,
        // backgroundColor: "w",
        flexDirection: "column",
        marginBottom: 20,
    },
    cardContent: {
        flexDirection: "row",
        marginLeft: 10,
    },
    tagsContent: {
        marginTop: 10,
        flexWrap: "wrap",
    },
    btnColor: {
        padding: 10,
        borderRadius: 40,
        marginHorizontal: 3,
        // backgroundColor: '#FAEBD7',
        backgroundColor: "#F5DEB3",
        // backgroundColor: '#87CEFA',
        // backgroundColor: '#90EE90',
        // backgroundColor: '#7FFF00',
        marginTop: 5,
    },
});
