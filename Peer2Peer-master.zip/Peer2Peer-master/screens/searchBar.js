/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj
 * @createdOn : 03-06-21
 * @modifiedOn : 03-12-21
 * @description : Contains the components used to display the SearchBar on top.
 *================================================================================================**/

import React, { useState, useEffect } from "react";
import { StyleSheet, View, TextInput, TouchableOpacity } from "react-native";
import { Icon } from "react-native-elements";
import axios from "axios";

export default function SearchBar() {
    const [searchText, setSearchText] = useState("");
    const [users, setUsers] = useState([]);
    const [filteredUsers, setFilteredUsers] = useState([]);

    // useEffect(() => {
    //     StatusBar.setBarStyle("dark-content", false);
    //     axios.get("https://randomuser.me/api/?results=150").then(({ data }) => {
    //         setUsers(data.results);
    //     });
    // }, []);

    return (
        <View style={styles.searchView}>
            <View style={styles.inputView}>
                <TextInput
                    defaultValue={searchText}
                    style={styles.input}
                    placeholder="Search"
                    textContentType="name"
                    onChangeText={(text) => {
                        setSearchText(text);
                        if (text === "") {
                            return setFilteredUsers([]);
                        }
                        const filtered_users = users.filter((user) =>
                            user.name.first
                                .toLowerCase()
                                .startsWith(text.toLowerCase())
                        );
                        setFilteredUsers(filtered_users);
                    }}
                    returnKeyType="search"
                />
                {searchText.length === 0 ? (
                    <TouchableOpacity>
                        <Icon name="search" size={24} color="#333" />
                    </TouchableOpacity>
                ) : (
                    <TouchableOpacity
                        onPress={() => {
                            setSearchText("");
                            setFilteredUsers([]);
                        }}
                    >
                        <Icon name="cancel" size={24} color="#333" />
                    </TouchableOpacity>
                )}
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    coverImage: { height: 300, width: "100%" },
    profileContainer: {
        // height: 1000,
        backgroundColor: "#fff",
        marginTop: -100,
        borderTopLeftRadius: 20,
        borderTopRightRadius: 20,
        //   box-shadow: 0 8px 6px -6px black,
    },
    profileImageView: {
        alignItems: "center",
        marginTop: -50,
    },
    profileImage: {
        width: 100,
        height: 100,
        borderRadius: 100,
        borderWidth: 3,
        borderColor: "#fff",
    },
    nameAndBioView: { alignItems: "center", marginTop: 10 },
    userFullName: { fontFamily: "Roboto", fontSize: 26 },
    userBio: {
        fontFamily: "Roboto",
        fontSize: 18,
        color: "#333",
        margin: 5,
        textAlign: "center",
    },
    countsView: { flexDirection: "row", marginTop: 20 },
    countView: { flex: 1, alignItems: "center" },
    countNum: { fontFamily: "Roboto", fontSize: 20 },
    countText: { fontFamily: "Roboto", fontSize: 18, color: "#333" },
    interactButtonsView: {
        flexDirection: "row",
        marginTop: 10,
        paddingHorizontal: 20,
    },
    interactButton: {
        flex: 1,
        flexDirection: "row",
        alignContent: "center",
        justifyContent: "center",
        backgroundColor: "#2196f3",
        margin: 5,
        borderRadius: 4,
    },
    interactButtonText: {
        fontFamily: "Roboto",
        color: "#fff",
        fontSize: 18,
        paddingVertical: 6,
    },
    profileContentButtonsView: {
        flexDirection: "row",
        borderTopWidth: 2,
        borderTopColor: "#f1f3f6",
    },
    showContentButton: {
        flex: 1,
        alignItems: "center",
        paddingVertical: 10,
        borderBottomColor: "#000",
    },
    showContentButtonText: {
        fontFamily: "Roboto",
        fontSize: 18,
    },
    searchView: {
        display: "flex",
        flexDirection: "row",
    },
    inputView: {
        flex: 1,
        height: 40,
        backgroundColor: "#fff",
        paddingHorizontal: 10,
        borderRadius: 6,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    input: {
        flex: 1,
        height: 40,
        fontSize: 18,
    },
    modal: {
        flex: 1,
        backgroundColor: "rgba(0,0,0,0.7)",
        justifyContent: "center",
        padding: 10,
        alignItems: "flex-end",
    },
    close: {
        color: "white",
        fontSize: 20,
        lineHeight: 25,
        fontWeight: "bold",
        borderColor: "white",
        borderWidth: 2,
        margin: 10,
        padding: 5,
        marginBottom: 60,
        alignSelf: "flex-end",
        textAlign: "center",
    },
});
