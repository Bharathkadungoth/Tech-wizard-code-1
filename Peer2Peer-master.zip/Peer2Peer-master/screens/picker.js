/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj
 * @createdOn : 03-02-21
 * @modifiedOn : 03-24-21
 * @description : Contains the picker components used to choose option(s) from a dropdown menu.
 *================================================================================================**/

import React, { useState, useEffect } from "react";
import { View } from "react-native";
import SelectBox from "react-native-multi-selectbox";
import { xorBy } from "lodash";
import { Component } from "react";

// Options data must contain 'item' & 'id' keys
const gender = [
    {
        item: "Male",
        id: "Male",
    },
    {
        item: "Female",
        id: "Female",
    },
    {
        item: "Other",
        id: "Other",
    },
];
export var Gender = (props) => {
    var currentVal = {
        item: props.currentGender.item,
        id: props.currentGender.id,
    };
    const [selectedGender, setSelectedGender] = useState(currentVal);

    var onChange = (gender) => {
        setSelectedGender(gender);
        props.onSelectGender(gender.item);
    };
    return (
        <SelectBox
            label="Gender"
            options={gender}
            value={selectedGender}
            onChange={onChange}
            hideInputFilter={true}
            arrowIconColor="black"
            // ==
            labelStyle={{ color: "transparent" }}
            selectedItemStyle={{ marginHorizontal: 10, color: "black" }}
            // selectedItemStyle={styles.selectedItemStyle}
            containerStyle={{
                width: "90%",
                marginHorizontal: 20,
                backgroundColor: "white",
                alignItems: "center",
            }}
            optionsLabelStyle={{ marginHorizontal: 10, color: "black" }}
            optionContainerStyle={{
                width: "90%",
                marginHorizontal: 20,
                backgroundColor: "white",
            }}
        />
    );
    function onChange() {
        (val) => setSelectedGender(val);
        props.onSelectGender(selectedGender.item);
    }
};

const role = [
    {
        item: "Mentor",
        id: "Mentor",
    },
    {
        item: "Mentee",
        id: "Mentee",
    },
    {
        item: "Investor",
        id: "Investor",
    },
];
export var Role = (props) => {
    var currentVal = {
        item: props.currentRole.item,
        id: props.currentRole.id,
    };
    const [selectedRole, setSelectedRole] = useState(currentVal);

    var onChange = (role) => {
        setSelectedRole(role);
        props.onSelectRole(role.item);
    };
    return (
        <SelectBox
            label="Role"
            options={role}
            value={selectedRole}
            onChange={onChange}
            hideInputFilter={true}
            // ==
            searchIconColor="blue"
            arrowIconColor="black"
            // ==
            labelStyle={{ color: "transparent" }}
            selectedItemStyle={{ marginHorizontal: 10, color: "black" }}
            // selectedItemStyle={styles.selectedItemStyle}
            containerStyle={{
                width: "90%",
                marginHorizontal: 20,
                backgroundColor: "white",
                alignItems: "center",
            }}
            // ==
            inputFilterStyle={{
                marginHorizontal: 10,
            }}
            inputFilterContainerStyle={{
                width: "90%",
                marginHorizontal: 20,
                backgroundColor: "yellow",
            }}
            // ==
            optionsLabelStyle={{ marginHorizontal: 10, color: "black" }}
            optionContainerStyle={{
                width: "90%",
                marginHorizontal: 20,
                backgroundColor: "white",
            }}
        />
    );
};

const interests = [
    {
        item: "Tech",
        id: "Tech",
    },
    {
        item: "Manufacturing",
        id: "Manufacturing",
    },
    {
        item: "Retail",
        id: "Retail",
    },
    {
        item: "Entrepreneurship",
        id: "Entrepreneurship",
    },
    {
        item: "Construction",
        id: "Construction",
    },
    {
        item: "Sports",
        id: "Sports",
    },
    {
        item: "Home",
        id: "Home",
    },
    {
        item: "Mechanical",
        id: "Mechanical",
    },
    {
        item: "Automotive",
        id: "Automotive",
    },
    {
        item: "Movies",
        id: "Movies",
    },
];
export var Interests = (props) => {
    const [selectedTeams, setSelectedTeams] = useState(props.currentInterests);
    props.onSelectInterests(selectedTeams);

    var onChange2 = (i) => {
        setSelectedTeams(xorBy(selectedTeams, [i], "id"));
    };

    return (
        <View>
            <SelectBox
                inputPlaceholder="What are your interests?"
                options={interests}
                selectedValues={selectedTeams}
                onMultiSelect={onChange2}
                onTapClose={onChange2}
                isMulti
                // ==
                searchIconColor="black"
                arrowIconColor="black"
                toggleIconColor="black"
                // ==
                labelStyle={{ color: "transparent" }}
                multiListEmptyLabelStyle={{
                    marginHorizontal: 10,
                    color: "black",
                }}
                containerStyle={{
                    width: "90%",
                    marginHorizontal: 20,
                    backgroundColor: "white",
                    alignItems: "center",
                }}
                // ==
                inputFilterStyle={{
                    marginHorizontal: 10,
                }}
                inputFilterContainerStyle={{
                    width: "90%",
                    marginHorizontal: 20,
                    backgroundColor: "white",
                }}
                // ==
                optionsLabelStyle={{ marginHorizontal: 10, color: "black" }}
                optionContainerStyle={{
                    width: "90%",
                    marginHorizontal: 20,
                    backgroundColor: "white",
                }}
                // ==
                multiOptionContainerStyle={{ backgroundColor: "black" }}
            />
        </View>
    );
    function onMultiChange() {
        return (item) => {
            setSelectedTeams(xorBy(selectedTeams, [item], "id"));
            console.log("object is", selectedTeams);
        };
    }
};
export class Test extends Component {
    state = {
        selectedGender: "",
    };
    onChange = (gender) => {
        this.setState({ selectedGender: gender });
        this.props.onSelectGender(gender.item);
    };

    render() {
        return (
            <SelectBox
                label="Gender"
                options={gender}
                value={this.state.selectedGender}
                // onChange={(val) => this.setState({ selectedGender: val })}
                onChange={this.onChange}
                hideInputFilter={true}
                // ==
                arrowIconColor="black"
                // ==
                labelStyle={{ color: "transparent" }}
                selectedItemStyle={{ marginHorizontal: 10, color: "black" }}
                // selectedItemStyle={styles.selectedItemStyle}
                containerStyle={{
                    width: "90%",
                    marginHorizontal: 20,
                    backgroundColor: "white",
                    alignItems: "center",
                }}
                optionsLabelStyle={{ marginHorizontal: 10, color: "black" }}
                optionContainerStyle={{
                    width: "90%",
                    marginHorizontal: 20,
                    backgroundColor: "white",
                }}
            />
        );
    }
}
