/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj
 * @createdOn : 03-06-21
 * @modifiedOn : 04-15-21
 * @description : Contains the components with which the user can either Login or Sign Up.
 *================================================================================================**/

import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    TouchableWithoutFeedback,
    Keyboard,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

import LoginScreen from "./Initial/LoginScreen";
import SignUpScreen from "./Initial/SignUpScreen";

export default class InitialScreen extends Component {
    state = {
        externalData: null,
        activeTab: "Login",
    };

    render() {
        var switchTab = (tab) => {
            if (tab === "Login") {
                this.setState({ activeTab: "SignUp" });
            } else {
                this.setState({ activeTab: "Login" });
            }
        };
        return (
            <TouchableWithoutFeedback onPress={() => Keyboard.dismiss()}>
                <LinearGradient
                    colors={["#090979", "#00d4ff"]}
                    style={styles.container}
                >
                    <Text style={styles.welcomeText}>
                        {this.state.activeTab === "Login"
                            ? "Welcome Back"
                            : "Sign Up Now"}
                    </Text>
                    <View style={styles.switchTabsView}>
                        <TouchableOpacity
                            style={{
                                borderBottomWidth:
                                    this.state.activeTab === "Login" ? 4 : 0,
                                borderBottomColor: "#fff",
                                paddingHorizontal: 4,
                                marginRight: 14,
                            }}
                            onPress={() => switchTab(this.state.activeTab)}
                        >
                            <Text style={styles.switchText}>Login</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={{
                                borderBottomWidth:
                                    this.state.activeTab === "SignUp" ? 4 : 0,
                                borderBottomColor: "#fff",
                                paddingHorizontal: 4,
                                marginRight: 14,
                            }}
                            onPress={() => switchTab(this.state.activeTab)}
                        >
                            <Text style={styles.switchText}>Sign Up</Text>
                        </TouchableOpacity>
                    </View>
                    {this.state.activeTab === "Login" ? (
                        <LoginScreen />
                    ) : (
                        <SignUpScreen />
                    )}
                </LinearGradient>
            </TouchableWithoutFeedback>
        );
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 40,
    },
    welcomeText: {
        alignSelf: "center",
        fontSize: 40,
        fontFamily: "Roboto",
        marginTop: 10,
        color: "#fff",
    },
    switchTabsView: {
        display: "flex",
        flexDirection: "row",
        paddingHorizontal: 20,
        marginTop: 20,
    },
    switchText: {
        padding: 2,
        fontSize: 20,
        color: "#fff",
        fontFamily: "Roboto",
    },
    inputView: {
        height: 40,
        borderBottomWidth: 1,
        borderBottomColor: "white",
        marginTop: 10,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    input: {
        flex: 1,
        height: 40,
        fontSize: 16,
        // fontFamily: "Roboto",
        paddingHorizontal: 4,
        color: "#fff",
    },
    button: {
        marginHorizontal: 20,
        backgroundColor: "#fafafa",
        marginTop: 12,
        paddingVertical: 10,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        marginTop: 20,
    },
    // buttonText: { fontFamily: "Roboto", fontSize: 16, color: "#E44D26" },
    buttonText: {
        fontFamily: "Roboto",
        fontSize: 18,
        color: "#000",
    },
    socialLoginView: {
        marginTop: 40,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
    },
    socialLoginTouchable: {
        backgroundColor: "#fff",
        width: 40,
        height: 40,
        borderRadius: 100,
        alignItems: "center",
        justifyContent: "center",
        marginHorizontal: 8,
    },
    errormsg: {
        fontSize: 12,
        color: "red",
        marginTop: 10,
        marginHorizontal: 20,
    },
});
