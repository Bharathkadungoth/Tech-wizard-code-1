/**================================================================================================
 **        ABOUT
 * @authors    : Aditya Bajaj, Gayathri Sitaraman
 * @createdOn : 03-06-21
 * @modifiedOn : 04-22-21
 * @description : Contains the components with which users can login to their account.
 *================================================================================================**/

import React, { Component } from "react";
import {
    Alert,
    StyleSheet,
    Text,
    View,
    TextInput,
    TouchableOpacity,
} from "react-native";

import AsyncStorage from "@react-native-async-storage/async-storage";
import { Icon } from "react-native-elements";
import * as yup from "yup";
import { Formik } from "formik";
import { Button } from "react-native-paper";
import { withNavigation } from "@react-navigation/compat";

/*AWS configs and related statements */
import * as queries from "../../src/graphql/queries";
import * as mutations from "../../src/graphql/mutations";
import * as subscriptions from "../../src/graphql/subscriptions";
import Amplify, { API, graphqlOperation, Auth } from "aws-amplify";
import awsconfig from "../../aws-exports";
Amplify.configure(awsconfig);

var SocialButtons = () => {
    return (
        <View style={styles.socialLoginView}>
            <TouchableOpacity style={styles.socialLoginTouchable}>
                <Icon
                    name="google"
                    type="font-awesome"
                    // color="#F16529"
                    color="#000"
                />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialLoginTouchable}>
                <Icon
                    name="facebook"
                    type="font-awesome"
                    // color="#F16529"
                    color="#000"
                />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialLoginTouchable}>
                <Icon
                    name="apple"
                    type="font-awesome"
                    // color="#F16529"
                    color="#000"
                />
            </TouchableOpacity>
        </View>
    );
};

async function authenticate(values) {
    var email = values.email;
    var pswd = values.password;

    try {
        var user = await Auth.signIn(email, pswd);
        /* var op = populateAsynctStorage(user.username);
        op.then(
            function (result) {
                console.log(result);
				return true;
            },
            function (err) {
                console.log(err);
            }
        ); */
	}catch(err) {console.log(err);return false;}
	try {
		var id = user.username;   
		var userdata = "";
		var userconnectiondata = "";

    
        var result = await API.graphql(
            graphqlOperation(queries.getProfile, {
                userid: id,
            })
        );
        userdata = result.data.getProfile;
        console.log("userdata", userdata);
        await AsyncStorage.setItem("Userdata", JSON.stringify(userdata)); //Profile data
        await AsyncStorage.setItem("myuserid", userdata.userid);

        console.log("done");
       
  
        const connresult = await API.graphql(
            graphqlOperation(queries.getConnectionsTable, {
                userID: id,
            })
        );
        if (connresult != null) {
            //console.log("haha",connresult);
            userconnectiondata = connresult.data.getConnectionsTable;
            // console.log("Conn table", userconnectiondata);
            await AsyncStorage.setItem(
                "ConnectionData",
                JSON.stringify(userconnectiondata)
            ); //Connections data
		}

    /* get active chats*/

   
        const myuserid = await AsyncStorage.getItem("myuserid");
        var lget = { userid: myuserid };
		try {
        result = await API.graphql(
            graphqlOperation(queries.getUserChannnelData, lget)
        );
		}catch(err) {console.log(err);}
        // console.log("Success",result.data.getUserChannnelData);
		
		if(result != null) {
        await AsyncStorage.setItem(
            "ActiveChannels",
            JSON.stringify(
                result.data.getUserChannnelData.activechannelandusers
            )
        );}
        return true;
    } catch (err) {
        console.log(err);
		return true;
    }
}

class LoginScreen extends Component {
    state = { showLoginPassword: false, success: false, btnstate: 0 };
    componentDidMount() {
        this.setState({ btnstate: 0 });
    }
    componentDidUpdate() {
        if (this.state.btnstate == 2) {
            this.setState({ btnstate: 0 });
        }
    }

    render() {
        return (
            <Formik
                // initialValues={{ email: "", password: "" }}
                initialValues={{
                    email: "test2@gmail.com",
                    password: "Pswd123!",
                }}
                onSubmit={(values) => {
                    console.log(values);
                    this.setState((previousState) => {
                        return {
                            btnstate: previousState.btnstate + 1,
                        };
                    });

                    var op = authenticate(values);
                    var that = this;
                    op.then(
                        function (result) {
                            if (result == true) {
                                that.setState((previousState) => {
                                    return {
                                        btnstate: previousState.btnstate + 1,
                                    };
                                });
                                that.props.navigation.navigate("Dashboard");
                            } else {
                                that.setState((previousState) => {
                                    return {
                                        btnstate: previousState.btnstate - 1,
                                    };
                                });
                            }
                        },
                        function (err) {
                            console.log(err);
                        }
                    );
                }}
                validationSchema={yup.object().shape({
                    email: yup
                        .string()
                        .email("Please enter a valid email")
                        .required("An email is required"),
                    password: yup
                        .string()
                        .required("A password is required")
                        .matches(
                            /\w*[a-z]\w*/,
                            "Password must have a small letter"
                        )
                        .matches(
                            /\w*[A-Z]\w*/,
                            "Password must have a capital letter"
                        )
                        .matches(/\d/, "Password must have a number")
                        .matches(
                            /[!@#$%^&*()\-_"=+{}; :,<.>]/,
                            "Password must have a special character"
                        )
                        .min(
                            8,
                            ({ min }) =>
                                `Password must be at least ${min} characters`
                        ),
                })}
            >
                {({
                    values,
                    handleChange,
                    errors,
                    setFieldTouched,
                    touched,
                    handleSubmit,
                }) => (
                    <View style={{ marginTop: 10 }}>
                        <View style={styles.inputView}>
                            <Icon
                                style={{ paddingHorizontal: 4 }}
                                name="envelope"
                                type="font-awesome"
                                color="#fff"
                                size={22}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Email"
                                placeholderTextColor="#f1f2f6"
                                keyboardType="email-address"
                                textContentType="emailAddress"
                                autoCompleteType="email"
                                returnKeyType="next"
                                value={values.email}
                                onChangeText={handleChange("email")}
                                onBlur={() => setFieldTouched("email")}
                            />
                        </View>
                        {touched.email && errors.email && (
                            <Text style={styles.errormsg}>{errors.email}</Text>
                        )}
                        <View style={styles.inputView}>
                            <Icon
                                style={{ paddingHorizontal: 4 }}
                                name="key"
                                type="font-awesome-5"
                                color="#fff"
                                size={22}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Password"
                                placeholderTextColor="#f1f2f6"
                                secureTextEntry={!this.state.showLoginPassword}
                                textContentType="password"
                                returnKeyType="done"
                                value={values.password}
                                onChangeText={handleChange("password")}
                                onBlur={() => setFieldTouched("password")}
                            />
                            <TouchableOpacity
                                style={{ paddingVertical: 4 }}
                                onPress={() => {
                                    this.setState({
                                        showLoginPassword: !this.state
                                            .showLoginPassword,
                                    });
                                }}
                            >
                                <Icon
                                    style={{ paddingHorizontal: 4 }}
                                    name="eye"
                                    type="font-awesome"
                                    color="#fff"
                                    size={22}
                                />
                            </TouchableOpacity>
                        </View>
                        {touched.password && errors.password && (
                            <Text style={styles.errormsg}>
                                {errors.password}
                            </Text>
                        )}
                        {this.state.btnstate == 0 && (
                            <Button
                                style={styles.btnlogin}
                                labelStyle={{
                                    textTransform: "none",
                                    fontFamily: "Roboto",
                                    fontSize: 18,
                                }}
                                color="#fafafa"
                                mode="contained"
                                onPress={handleSubmit}
                            >
                                Login
                            </Button>
                        )}
                        {this.state.btnstate == 1 && (
                            <Button
                                style={styles.btnlogin}
                                labelStyle={{
                                    textTransform: "none",
                                    fontFamily: "Roboto",
                                    fontSize: 18,
                                }}
                                color="#fafafa"
                                mode="contained"
                                loading
                            >
                                Checking
                            </Button>
                        )}
                        <TouchableOpacity
                            onPress={() =>
                                this.props.navigation.navigate("ForgotPassword")
                            }
                        >
                            <Text style={styles.forgotPasswordText}>
                                Forgot Password?
                            </Text>
                        </TouchableOpacity>
                        <SocialButtons />
                    </View>
                )}
            </Formik>
        );
    }
}
export default withNavigation(LoginScreen);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 40,
    },
    inputView: {
        height: 40,
        borderBottomWidth: 1,
        borderBottomColor: "white",
        marginTop: 10,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    input: {
        flex: 1,
        height: 40,
        fontSize: 16,
        // fontFamily: "Roboto",
        paddingHorizontal: 4,
        color: "#fff",
    },
    btnlogin: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        margin: 20,
    },
    button: {
        marginHorizontal: 20,
        backgroundColor: "#fafafa",
        // marginTop: 12,
        paddingVertical: 10,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        marginTop: 20,
        alignItems: "center",
        justifyContent: "center",
    },
    buttonText: {
        fontFamily: "Roboto",
        fontSize: 18,
        color: "#000",
    },
    forgotPasswordText: {
        marginHorizontal: 20,
        marginTop: 20,
        alignSelf: "flex-end",
        color: "#fff",
        fontSize: 18,
        fontFamily: "Roboto",
    },
    socialLoginView: {
        marginTop: 40,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
    },
    socialLoginTouchable: {
        backgroundColor: "#fff",
        width: 40,
        height: 40,
        borderRadius: 100,
        alignItems: "center",
        justifyContent: "center",
        marginHorizontal: 8,
    },
    errormsg: {
        fontSize: 12,
        color: "#FF6347",
        marginTop: 10,
        marginHorizontal: 20,
    },
});
