/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj, Gayathri Sitaraman
 * @createdOn : 03-06-21
 * @modifiedOn : 04-22-21
 * @description : Contains the components with which the user can sign up.
 *================================================================================================**/

import React, { useState, Component } from "react";
import {
    Alert,
    StyleSheet,
    Text,
    View,
    TextInput,
    TouchableOpacity,
} from "react-native";

import { Icon } from "react-native-elements";
import * as yup from "yup";
import { Formik } from "formik";
import { withNavigation } from "@react-navigation/compat";
import { Button } from "react-native-paper";

/*AWS configs and related statements */
import * as queries from "../../src/graphql/queries";
import * as mutations from "../../src/graphql/mutations";
import Amplify, { API, graphqlOperation, Auth } from "aws-amplify";
import awsconfig from "../../aws-exports";
Amplify.configure(awsconfig);

import AsyncStorage from "@react-native-async-storage/async-storage";

var SocialButtons = () => {
    return (
        <View
            style={[
                styles.socialLoginView,
                {
                    marginTop: 14,
                    justifyContent: "flex-start",
                },
            ]}
        >
            <TouchableOpacity
                style={[styles.socialLoginTouchable, { marginLeft: 0 }]}
            >
                <Icon name="google" type="font-awesome" color="#000" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialLoginTouchable}>
                <Icon name="facebook" type="font-awesome" color="#000" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.socialLoginTouchable}>
                <Icon
                    name="apple"
                    type="font-awesome"
                    // color="#F16529"
                    color="#000"
                />
            </TouchableOpacity>
        </View>
    );
};

async function signUpNow(values) {
    try {
        var email = values.email;
        var password = values.password;
        var username = email;
        const userinfo = await Auth.signUp({
            username,
            email,
            password,
        });
        console.log("Signing up User", userinfo.userSub);
        const id = userinfo.userSub;
        await AsyncStorage.setItem("myuserid", id);
        await AsyncStorage.setItem("ActiveChannels", null);
        await AsyncStorage.setItem("ConnectionData", null);
        return true;
    } catch (error) {
        console.log("error signing up:", error);
        return false;
    }
}
class SignUpScreen extends Component {
    state = { showRegisterPassword: false, btnstate: 0 };
    render() {
        return (
            <Formik
                // initialValues={{
                //     email: "",
                //     password: "",
                //     repswd: "",
                // }}
                initialValues={{
                    email: "a@a.com",
                    password: "Q!q12345",
                    repswd: "Q!q12345",
                }}
                onSubmit={(values) => {
                    console.log("values are", values);
                    this.setState((previousState) => {
                        return {
                            btnstate: previousState.btnstate + 1,
                        };
                    });
                    var op = signUpNow(values);
                    var that = this;
                    op.then(
                        function (result) {
                            if (result == true) {
                                that.props.navigation.navigate("Register", {
                                    email: values.email,
                                    password: values.password,
                                });
                            } else {
                                that.setState((previousState) => {
                                    return {
                                        btnstate: previousState.btnstate - 1,
                                    };
                                });
                            }
                        },
                        function (err) {
                            console.log(err);
                        }
                    );
                }}
                validationSchema={yup.object().shape({
                    email: yup
                        .string()
                        .email("Please enter a valid email")
                        .required("An email is required"),
                    password: yup
                        .string()
                        .required("A password is required")
                        .matches(
                            /\w*[a-z]\w*/,
                            "Password must have a small letter"
                        )
                        .matches(
                            /\w*[A-Z]\w*/,
                            "Password must have a capital letter"
                        )
                        .matches(/\d/, "Password must have a number")
                        .matches(
                            /[!@#$%^&*()\-_"=+{}; :,<.>]/,
                            "Password must have a special character"
                        )
                        .min(
                            8,
                            ({ min }) =>
                                `Password must be at least ${min} characters`
                        ),
                    repswd: yup
                        .string()
                        .required("Please re-type your password")
                        .oneOf(
                            [yup.ref("password"), null],
                            "Passwords must match"
                        ),
                })}
            >
                {({
                    values,
                    handleChange,
                    errors,
                    setFieldTouched,
                    touched,
                    handleSubmit,
                }) => (
                    <View style={{ marginTop: 10 }}>
                        <View style={styles.inputView}>
                            <Icon
                                style={{ paddingHorizontal: 4, width: 30 }}
                                name="envelope"
                                type="font-awesome"
                                color="#fff"
                                size={22}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Email"
                                placeholderTextColor="#f1f2f6"
                                keyboardType="email-address"
                                textContentType="emailAddress"
                                autoCompleteType="email"
                                returnKeyType="next"
                                value={values.email}
                                onChangeText={handleChange("email")}
                                onBlur={() => setFieldTouched("email")}
                            />
                        </View>
                        {touched.email && errors.email && (
                            <Text style={styles.errormsg}>{errors.email}</Text>
                        )}
                        <View style={styles.inputView}>
                            <Icon
                                style={{ paddingHorizontal: 4, width: 30 }}
                                name="key"
                                type="font-awesome-5"
                                color="#fff"
                                size={22}
                            />
                            <TextInput
                                style={styles.input}
                                value={values.password}
                                placeholder="Password"
                                placeholderTextColor="#f1f2f6"
                                secureTextEntry={
                                    !this.state.showRegisterPassword
                                }
                                textContentType="password"
                                returnKeyType="done"
                                onChangeText={handleChange("password")}
                                onBlur={() => setFieldTouched("password")}
                            />
                            <TouchableOpacity
                                style={{ paddingVertical: 4 }}
                                onPress={() => {
                                    this.setState({
                                        showRegisterPassword: !this.state
                                            .showRegisterPassword,
                                    });
                                }}
                            >
                                <Icon
                                    style={{ paddingHorizontal: 4 }}
                                    name="eye"
                                    type="font-awesome"
                                    color="#fff"
                                    size={22}
                                />
                            </TouchableOpacity>
                        </View>
                        {touched.password && errors.password && (
                            <Text style={styles.errormsg}>
                                {errors.password}
                            </Text>
                        )}

                        <View style={styles.inputView}>
                            <Icon
                                style={{ paddingHorizontal: 4, width: 30 }}
                                name="key"
                                type="font-awesome-5"
                                color="#fff"
                                size={22}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Re-Enter Password"
                                placeholderTextColor="#f1f2f6"
                                secureTextEntry={
                                    !this.state.showRegisterPassword
                                }
                                textContentType="password"
                                returnKeyType="done"
                                value={values.repswd}
                                onChangeText={handleChange("repswd")}
                                onBlur={() => setFieldTouched("repswd")}
                            />
                        </View>
                        {touched.repswd && errors.repswd && (
                            <Text style={styles.errormsg}>{errors.repswd}</Text>
                        )}
                        {this.state.btnstate == 0 && (
                            <Button
                                style={styles.btnlogin}
                                labelStyle={{
                                    textTransform: "none",
                                    fontFamily: "Roboto",
                                    fontSize: 18,
                                }}
                                color="#fafafa"
                                mode="contained"
                                onPress={handleSubmit}
                            >
                                Sign Up
                            </Button>
                        )}
                        {this.state.btnstate == 1 && (
                            <Button
                                style={styles.btnlogin}
                                labelStyle={{
                                    textTransform: "none",
                                    fontFamily: "Roboto",
                                    fontSize: 18,
                                }}
                                color="#fafafa"
                                mode="contained"
                                loading
                            >
                                Checking
                            </Button>
                        )}
                        <View>
                            <Text
                                style={{
                                    marginHorizontal: 20,
                                    marginTop: 30,
                                    fontSize: 18,
                                    color: "#fff",
                                    fontFamily: "Roboto",
                                }}
                            >
                                Or Register with
                            </Text>
                            <SocialButtons />
                        </View>
                    </View>
                )}
            </Formik>
        );
    }
}
export default withNavigation(SignUpScreen);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 40,
    },
    inputView: {
        height: 40,
        borderBottomWidth: 1,
        borderBottomColor: "white",
        marginTop: 10,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    btnlogin: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        margin: 20,
    },
    input: {
        flex: 1,
        height: 40,
        fontSize: 16,
        // fontFamily: "Roboto",
        paddingHorizontal: 4,
        color: "#fff",
    },
    button: {
        marginHorizontal: 20,
        backgroundColor: "#fafafa",
        marginTop: 12,
        paddingVertical: 10,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        marginTop: 20,
    },
    // buttonText: { fontFamily: "Roboto", fontSize: 16, color: "#E44D26" },
    buttonText: {
        fontFamily: "Roboto",
        fontSize: 18,
        color: "#000",
    },
    socialLoginView: {
        marginTop: 40,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
    },
    socialLoginTouchable: {
        backgroundColor: "#fff",
        width: 40,
        height: 40,
        borderRadius: 100,
        alignItems: "center",
        justifyContent: "center",
        marginHorizontal: 8,
    },
    errormsg: {
        fontSize: 12,
        color: "red",
        marginTop: 10,
        marginHorizontal: 20,
    },
});
