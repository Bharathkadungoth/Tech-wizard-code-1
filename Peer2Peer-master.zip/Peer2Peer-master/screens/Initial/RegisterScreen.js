/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj, Gayathri Sitaraman
 * @createdOn : 03-02-21
 * @modifiedOn : 04-22-21
 * @description : Contains the components with which the user can register in the system.
 *================================================================================================**/

import React, { Component } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
    Alert,
    StyleSheet,
    Text,
    View,
    TextInput,
    ScrollView,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Icon } from "react-native-elements";
import * as yup from "yup";
import { Formik } from "formik";
import "yup-phone";
import { withNavigation } from "@react-navigation/compat";
import { Button } from "react-native-paper";

import Amplify from "aws-amplify";
import { API, graphqlOperation } from "aws-amplify";
import config from "../../aws-exports";
Amplify.configure(config);

import { createProfile } from "../../src/graphql/mutations";

import { Gender } from "../picker";
import { Role } from "../picker";
import { Interests } from "../picker";

async function addProfile(values) {
    const myid = await AsyncStorage.getItem("myuserid");
    var interests = [];
    for (var i = 0; i < values.interests.length; i++) {
        interests.push(values.interests[i].item);
    }
    const input = {
        id: myid,
        userid: myid,
        name: values.name,
        gender: values.gender,
        phone_number: values.phone,
        role: values.role,
        business_interests: interests,
        expert_in: [],
        bio: values.about,
        email: values.email,
        events: [],
        perks: [],
        connections: [],
    };

    try {
        await AsyncStorage.setItem("Userdata", JSON.stringify(input));
        await API.graphql(graphqlOperation(createProfile, { input }));
        return true;
    } catch (err) {
        console.log(err);
        return false;
    }
}
class RegisterScreen extends Component {
    constructor(props) {
        super(props);

        this.state = {
            name: "",
            phone: "",
            about: "",
            gender: "",
            role: "",
            interests: [],
            email: this.props.route.params.email,
            password: this.props.route.params.password,
            id: this.props.route.params.id,
            btnstate: 0,
        };
    }

    render() {
        return (
            <Formik
                initialValues={this.state}
                onSubmit={(values) => {
                    this.setState((previousState) => {
                        return {
                            btnstate: previousState.btnstate + 1,
                        };
                    });

                    var op = addProfile(values);
                    var that = this;
                    op.then(
                        function (result) {
                            if (result == true) {
                                that.props.navigation.navigate("Dashboard");
                            } else {
                                that.setState((previousState) => {
                                    return {
                                        btnstate: previousState.btnstate - 1,
                                    };
                                });
                            }
                        },
                        function (err) {
                            console.log(err);
                        }
                    );
                }}
                validationSchema={yup.object().shape({
                    name: yup
                        .string()
                        .required("Full name is required")
                        .matches(/\w/, "Enter at least 1 word"),
                    phone: yup
                        .string()
                        .required("Number is required")
                        .phone("US", true, "Number is invalid"),
                    about: yup
                        .string()
                        .required("Please write something about yourself")
                        .matches(/(\w.+\s){4}.\w/, "Enter at least 5 words"),
                    gender: yup.string().required("Please state your gender"),
                    role: yup.string().required("Please state your role"),
                    interests: yup.array().required("needed bro"),
                })}
            >
                {({
                    values,
                    handleChange,
                    errors,
                    setFieldTouched,
                    touched,
                    handleSubmit,
                }) => (
                    <LinearGradient
                        colors={["#090979", "#00d4ff"]}
                        style={styles.container}
                    >
                        <ScrollView showsVerticalScrollIndicator={false}>
                            <View style={styles.inputView}>
                                <Icon
                                    style={{ paddingHorizontal: 4, width: 30 }}
                                    name="user"
                                    type="font-awesome"
                                    color="#fff"
                                    size={22}
                                />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Full Name"
                                    placeholderTextColor="#f1f2f6"
                                    textContentType="name"
                                    autoCompleteType="name"
                                    returnKeyType="next"
                                    value={values.name}
                                    onChangeText={handleChange("name")}
                                    onBlur={() => setFieldTouched("name")}
                                />
                            </View>
                            {touched.name && errors.name && (
                                <Text style={styles.errormsg}>
                                    {errors.name}
                                </Text>
                            )}
                            <View style={styles.inputView}>
                                <Icon
                                    style={{ paddingHorizontal: 4, width: 30 }}
                                    name="phone"
                                    type="font-awesome"
                                    color="#fff"
                                    size={22}
                                />
                                <TextInput
                                    style={styles.input}
                                    selectionColor="white"
                                    placeholder="Phone"
                                    placeholderTextColor="#f1f2f6"
                                    keyboardType="phone-pad"
                                    returnKeyType="next"
                                    autoCompleteType="tel"
                                    value={values.phone}
                                    onChangeText={handleChange("phone")}
                                    onBlur={() => setFieldTouched("phone")}
                                />
                            </View>
                            {touched.phone && errors.phone && (
                                <Text style={styles.errormsg}>
                                    {errors.phone}
                                </Text>
                            )}
                            <View style={styles.inputView}>
                                <Icon
                                    style={{ paddingHorizontal: 4, width: 30 }}
                                    name="id-card"
                                    type="font-awesome"
                                    color="#fff"
                                    size={22}
                                />
                                <TextInput
                                    style={styles.input}
                                    placeholder="About you"
                                    placeholderTextColor="#f1f2f6"
                                    textContentType="name"
                                    returnKeyType="next"
                                    value={values.about}
                                    onChangeText={handleChange("about")}
                                    onBlur={() => setFieldTouched("about")}
                                />
                            </View>
                            {touched.about && errors.about && (
                                <Text style={styles.errormsg}>
                                    {errors.about}
                                </Text>
                            )}

                            <Gender
                                currentGender={{
                                    item: "",
                                    id: "",
                                }}
                                onSelectGender={(g) => {
                                    values.gender = g;
                                    setFieldTouched("gender");
                                }}
                            />
                            {touched.gender && errors.gender && (
                                <Text style={styles.errormsg}>
                                    {errors.gender}
                                </Text>
                            )}

                            <Role
                                currentRole={{
                                    item: "",
                                    id: "",
                                }}
                                onSelectRole={(r) => {
                                    values.role = r;
                                    setFieldTouched("role");
                                }}
                            />
                            {touched.role && errors.role && (
                                <Text style={styles.errormsg}>
                                    {errors.role}
                                </Text>
                            )}

                            <Interests
                                currentInterests={[]}
                                onSelectInterests={(i) => {
                                    values.interests = i;
                                }}
                            />

                            {this.state.btnstate == 0 && (
                                <Button
                                    style={styles.btnlogin}
                                    labelStyle={{
                                        textTransform: "none",
                                        fontFamily: "Roboto",
                                        fontSize: 18,
                                    }}
                                    color="#fafafa"
                                    mode="contained"
                                    onPress={handleSubmit}
                                >
                                    Register
                                </Button>
                            )}
                            {this.state.btnstate == 1 && (
                                <Button
                                    style={styles.btnlogin}
                                    labelStyle={{
                                        textTransform: "none",
                                        fontFamily: "Roboto",
                                        fontSize: 18,
                                    }}
                                    color="#fafafa"
                                    mode="contained"
                                    loading
                                >
                                    Checking
                                </Button>
                            )}
                        </ScrollView>
                    </LinearGradient>
                )}
            </Formik>
        );
    }
}
export default withNavigation(RegisterScreen);

const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 40,
    },
    inputView: {
        height: 40,
        borderBottomWidth: 1,
        borderBottomColor: "white",
        marginTop: 10,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    input: {
        flex: 1,
        height: 40,
        fontSize: 20,
        paddingHorizontal: 4,
        color: "white",
        backgroundColor: "transparent",
    },
    button: {
        marginHorizontal: 20,
        backgroundColor: "#fafafa",
        paddingVertical: 10,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        marginTop: 20,
        marginBottom: 20,
    },
    // buttonText: { fontFamily: "Roboto", fontSize: 16, color: "#E44D26" },
    buttonText: {
        fontSize: 18,
        color: "#000",
    },
    errormsg: {
        fontSize: 12,
        color: "#FF6347",
        marginTop: 10,
        marginHorizontal: 20,
    },
    btnlogin: {
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        margin: 20,
    },
});
