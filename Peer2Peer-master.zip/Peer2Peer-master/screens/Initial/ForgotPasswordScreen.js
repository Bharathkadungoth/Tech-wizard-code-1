/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj, @Gayathri Sitaraman
 * @createdOn : 04-13-21
 * @modifiedOn : 04-13-21
 * @description : Contains the components with which users can reset their password.
 *================================================================================================**/

import React, { useState, Component } from "react";
import {
    Alert,
    StyleSheet,
    Text,
    View,
    TextInput,
    TouchableOpacity,
} from "react-native";

import { Icon } from "react-native-elements";
import * as yup from "yup";
import { Formik } from "formik";
import { Button } from "react-native-paper";
import { useNavigation } from "@react-navigation/native";
import { LinearGradient } from "expo-linear-gradient";

/*AWS configs and related statements */
import * as queries from "../../src/graphql/queries";
import * as mutations from "../../src/graphql/mutations";
import * as subscriptions from "../../src/graphql/subscriptions";
import Amplify, { API, graphqlOperation, Auth } from "aws-amplify";
import awsconfig from "../../aws-exports";
Amplify.configure(awsconfig);

var TY = () => {
    return (
        <View style={styles.socialLoginView}>
            <Text>Please check your mail for further steps</Text>
        </View>
    );
};

export function ForgotPasswordScreenOLD({ navigation }) {
    var [showReply, setShowReply] = useState(false);
    const [showLoginPassword, setShowLoginPassword] = useState(false);
    var [showForm, setShowForm] = useState(false);

    return (
        <Formik
            initialValues={{ email: "", code: "", password: "" }}
            // initialValues={{ email: "test@gmail.com" }}
            onSubmit={(values) => {
                console.log(values);
                setShowReply((showReply = true));
            }}
            validationSchema={yup.object().shape({
                email: yup
                    .string()
                    .email("Please enter a valid email")
                    .required("An email is required"),
                code: yup
                    .string()
                    .required("A verification code is required")
                    .matches(/^\d+$/, "The verification code only has numbers")
                    .length(
                        6,
                        "The verification code should be of 6 characters "
                    ),
                password: yup
                    .string()
                    .required("A password is required")
                    .matches(/\w*[a-z]\w*/, "Password must have a small letter")
                    .matches(
                        /\w*[A-Z]\w*/,
                        "Password must have a capital letter"
                    )
                    .matches(/\d/, "Password must have a number")
                    .matches(
                        /[!@#$%^&*()\-_"=+{}; :,<.>]/,
                        "Password must have a special character"
                    )
                    .min(
                        8,
                        ({ min }) =>
                            `Password must be at least ${min} characters`
                    ),
            })}
        >
            {({
                values,
                handleChange,
                errors,
                setFieldTouched,
                touched,
                handleSubmit,
            }) => (
                <LinearGradient
                    colors={["#090979", "#00d4ff"]}
                    style={styles.container}
                >
                    <View style={{ marginTop: 10 }}>
                        <View style={styles.inputView}>
                            <Icon
                                style={{ paddingHorizontal: 4 }}
                                name="envelope"
                                type="font-awesome"
                                color="#fff"
                                size={22}
                            />
                            <TextInput
                                style={styles.input}
                                placeholder="Email"
                                placeholderTextColor="#f1f2f6"
                                keyboardType="email-address"
                                textContentType="emailAddress"
                                autoCompleteType="email"
                                returnKeyType="next"
                                value={values.email}
                                onChangeText={handleChange("email")}
                                onBlur={() => setFieldTouched("email")}
                            />
                        </View>
                        {touched.email && errors.email && (
                            <Text style={styles.errormsg}>{errors.email}</Text>
                        )}
                        <TouchableOpacity
                            style={[
                                styles.button,
                                {
                                    backgroundColor: "#FFE4C4",
                                    width: "20%",
                                },
                            ]}
                            onPress={() => {
                                resetPassword(values);
                                setShowForm((showForm = true));
                            }}
                        >
                            <Text style={styles.buttonText}>Get Code</Text>
                        </TouchableOpacity>

                        {showForm && (
                            <View>
                                <View style={styles.inputView}>
                                    <Icon
                                        style={{ paddingHorizontal: 4 }}
                                        name="user-check"
                                        type="font-awesome-5"
                                        color="#fff"
                                        size={22}
                                    />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="Verification Code"
                                        placeholderTextColor="#f1f2f6"
                                        textContentType="telephoneNumber"
                                        returnKeyType="done"
                                        value={values.code}
                                        onChangeText={handleChange("code")}
                                        onBlur={() => setFieldTouched("code")}
                                    />
                                </View>
                                {touched.code && errors.code && (
                                    <Text style={styles.errormsg}>
                                        {errors.code}
                                    </Text>
                                )}
                                <View style={styles.inputView}>
                                    <Icon
                                        style={{ paddingHorizontal: 4 }}
                                        name="key"
                                        type="font-awesome-5"
                                        color="#fff"
                                        size={22}
                                    />
                                    <TextInput
                                        style={styles.input}
                                        placeholder="New Password"
                                        placeholderTextColor="#f1f2f6"
                                        secureTextEntry={!showLoginPassword}
                                        textContentType="password"
                                        returnKeyType="done"
                                        value={values.password}
                                        onChangeText={handleChange("password")}
                                        onBlur={() =>
                                            setFieldTouched("password")
                                        }
                                    />
                                    <TouchableOpacity
                                        style={{ paddingVertical: 4 }}
                                        onPress={() => {
                                            setShowLoginPassword(
                                                !showLoginPassword
                                            );
                                        }}
                                    >
                                        <Icon
                                            style={{ paddingHorizontal: 4 }}
                                            name="eye"
                                            type="font-awesome"
                                            color="#fff"
                                            size={22}
                                        />
                                    </TouchableOpacity>
                                </View>
                                {touched.password && errors.password && (
                                    <Text style={styles.errormsg}>
                                        {errors.password}
                                    </Text>
                                )}
                                <TouchableOpacity
                                    style={styles.button}
                                    onPress={() => {
                                        // enterCodeandReset(values);
                                    }}
                                >
                                    <Text style={styles.buttonText}>
                                        Reset password
                                    </Text>
                                </TouchableOpacity>
                            </View>
                        )}
                    </View>
                </LinearGradient>
            )}
        </Formik>
    );
}
async function resetPassword(values) {
    /* sending email to the person */
    try {
        await Auth.forgotPassword(values.email);
        console.log("Sent");
    } catch (error) {
        console.log(
            "MAke sure your email id is valid and is registered with the app"
        );
        //onError(error);
    }
}

async function enterCodeandReset(values) {
    /* enter new password and verification code*/
    var email = values.email;
    var code = values.code;
    var password = values.password;
    try {
        await Auth.forgotPasswordSubmit(email, code, password);
        return true;
    } catch (error) {
        console.log(error.message);
        return false;
    }
}
export default class ForgotPasswordScreen extends Component {
    state = { showReply: false, showLoginPassword: false, showForm: false };

    render() {
        return (
            <Formik
                initialValues={{ email: "", code: "", password: "" }}
                // initialValues={{ email: "test@gmail.com", code: "123456", password: "Qq!12345"  }}
                onSubmit={(values) => {
                    console.log(values);

                    var op = enterCodeandReset(values);
                    var that = this;
                    op.then(
                        function (result) {
                            if (result == true) {
                                that.props.navigation.navigate("Login");
                            } else {
                            }
                        },
                        function (err) {
                            console.log(err);
                        }
                    );
                    // this.setState({
                    //     showReply: true,
                    // });
                }}
                validationSchema={yup.object().shape({
                    email: yup
                        .string()
                        .email("Please enter a valid email")
                        .required("An email is required"),
                    code: yup
                        .string()
                        .required("A verification code is required")
                        .matches(
                            /^\d+$/,
                            "The verification code only has numbers"
                        )
                        .length(
                            6,
                            "The verification code should be of 6 characters "
                        ),
                    password: yup
                        .string()
                        .required("A password is required")
                        .matches(
                            /\w*[a-z]\w*/,
                            "Password must have a small letter"
                        )
                        .matches(
                            /\w*[A-Z]\w*/,
                            "Password must have a capital letter"
                        )
                        .matches(/\d/, "Password must have a number")
                        .matches(
                            /[!@#$%^&*()\-_"=+{}; :,<.>]/,
                            "Password must have a special character"
                        )
                        .min(
                            8,
                            ({ min }) =>
                                `Password must be at least ${min} characters`
                        ),
                })}
            >
                {({
                    values,
                    handleChange,
                    errors,
                    setFieldTouched,
                    touched,
                    handleSubmit,
                }) => (
                    <LinearGradient
                        colors={["#090979", "#00d4ff"]}
                        style={styles.container}
                    >
                        <View style={{ marginTop: 10 }}>
                            <View style={styles.inputView}>
                                <Icon
                                    style={{ paddingHorizontal: 4 }}
                                    name="envelope"
                                    type="font-awesome"
                                    color="#fff"
                                    size={22}
                                />
                                <TextInput
                                    style={styles.input}
                                    placeholder="Email"
                                    placeholderTextColor="#f1f2f6"
                                    keyboardType="email-address"
                                    textContentType="emailAddress"
                                    autoCompleteType="email"
                                    returnKeyType="next"
                                    value={values.email}
                                    onChangeText={handleChange("email")}
                                    onBlur={() => setFieldTouched("email")}
                                />
                            </View>
                            {touched.email && errors.email && (
                                <Text style={styles.errormsg}>
                                    {errors.email}
                                </Text>
                            )}
                            <TouchableOpacity
                                style={[
                                    styles.button,
                                    {
                                        backgroundColor: "#FFE4C4",
                                        width: "20%",
                                    },
                                ]}
                                onPress={() => {
                                    resetPassword(values);
                                    this.setState({
                                        showForm: true,
                                    });
                                }}
                            >
                                <Text style={styles.buttonText}>Get Code</Text>
                            </TouchableOpacity>

                            {this.state.showForm && (
                                <View>
                                    <View style={styles.inputView}>
                                        <Icon
                                            style={{ paddingHorizontal: 4 }}
                                            name="user-check"
                                            type="font-awesome-5"
                                            color="#fff"
                                            size={22}
                                        />
                                        <TextInput
                                            style={styles.input}
                                            placeholder="Verification Code"
                                            placeholderTextColor="#f1f2f6"
                                            textContentType="telephoneNumber"
                                            returnKeyType="done"
                                            value={values.code}
                                            onChangeText={handleChange("code")}
                                            onBlur={() =>
                                                setFieldTouched("code")
                                            }
                                        />
                                    </View>
                                    {touched.code && errors.code && (
                                        <Text style={styles.errormsg}>
                                            {errors.code}
                                        </Text>
                                    )}
                                    <View style={styles.inputView}>
                                        <Icon
                                            style={{ paddingHorizontal: 4 }}
                                            name="key"
                                            type="font-awesome-5"
                                            color="#fff"
                                            size={22}
                                        />
                                        <TextInput
                                            style={styles.input}
                                            placeholder="New Password"
                                            placeholderTextColor="#f1f2f6"
                                            secureTextEntry={
                                                !this.state.showLoginPassword
                                            }
                                            textContentType="password"
                                            returnKeyType="done"
                                            value={values.password}
                                            onChangeText={handleChange(
                                                "password"
                                            )}
                                            onBlur={() =>
                                                setFieldTouched("password")
                                            }
                                        />
                                        <TouchableOpacity
                                            style={{ paddingVertical: 4 }}
                                            onPress={() => {
                                                this.setState({
                                                    showLoginPassword: !this
                                                        .state
                                                        .showLoginPassword,
                                                });
                                            }}
                                        >
                                            <Icon
                                                style={{ paddingHorizontal: 4 }}
                                                name="eye"
                                                type="font-awesome"
                                                color="#fff"
                                                size={22}
                                            />
                                        </TouchableOpacity>
                                    </View>
                                    {touched.password && errors.password && (
                                        <Text style={styles.errormsg}>
                                            {errors.password}
                                        </Text>
                                    )}
                                    <TouchableOpacity
                                        style={styles.button}
                                        onPress={handleSubmit}
                                    >
                                        <Text style={styles.buttonText}>
                                            Reset password
                                        </Text>
                                    </TouchableOpacity>
                                </View>
                            )}
                        </View>
                    </LinearGradient>
                )}
            </Formik>
        );
    }
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        paddingTop: 40,
    },
    welcomeText: {
        alignSelf: "center",
        fontSize: 40,
        fontFamily: "Roboto",
        marginTop: 10,
        color: "#fff",
    },
    switchTabsView: {
        display: "flex",
        flexDirection: "row",
        paddingHorizontal: 20,
        marginTop: 20,
    },
    switchText: {
        padding: 2,
        fontSize: 20,
        color: "#fff",
        fontFamily: "Roboto",
    },
    inputView: {
        height: 40,
        borderBottomWidth: 1,
        borderBottomColor: "white",
        marginTop: 10,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
    },
    input: {
        flex: 1,
        height: 40,
        fontSize: 16,
        // fontFamily: "Roboto",
        paddingHorizontal: 4,
        color: "#fff",
    },
    button: {
        marginHorizontal: 20,
        backgroundColor: "#fafafa",
        // marginTop: 12,
        paddingVertical: 10,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        marginTop: 20,
        alignItems: "center",
        justifyContent: "center",
    },
    // buttonText: { fontFamily: "Roboto", fontSize: 16, color: "#E44D26" },
    buttonText: {
        fontFamily: "Roboto",
        fontSize: 18,
        color: "#000",
    },
    forgotPasswordText: {
        marginHorizontal: 20,
        marginTop: 20,
        alignSelf: "flex-end",
        color: "#fff",
        fontSize: 18,
        fontFamily: "Roboto",
    },
    socialLoginView: {
        backgroundColor: "wheat",
        padding: 10,
        marginTop: 40,
        marginHorizontal: 20,
        display: "flex",
        flexDirection: "row",
        justifyContent: "center",
    },
    socialLoginTouchable: {
        backgroundColor: "#fff",
        width: 40,
        height: 40,
        borderRadius: 100,
        alignItems: "center",
        justifyContent: "center",
        marginHorizontal: 8,
    },
    errormsg: {
        fontSize: 12,
        color: "#FF6347",
        marginTop: 10,
        marginHorizontal: 20,
    },
});
