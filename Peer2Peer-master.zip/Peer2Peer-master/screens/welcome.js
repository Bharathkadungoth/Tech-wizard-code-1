/**================================================================================================
 **        ABOUT
 * @author    : Rishika Bera
 * @createdOn : 04-03-21
 * @modifiedOn : 04-21-21
 * @description : Contains the code for splash screen
 *================================================================================================**/


import React, { useRef, useEffect } from "react";
import {
    SafeAreaView,
    Image,
    Button,
    Text,
    View,
    StyleSheet,
    Dimensions,
    Animated,
} from "react-native";
import { useNavigation } from "@react-navigation/native";

const App = () => {
    const moveAnim = useRef(new Animated.Value(0)).current;
    const fadeAnim = useRef(new Animated.Value(0)).current;

    useEffect(() => {
        Animated.sequence([
            Animated.timing(moveAnim, {
                duration: 2000,
                toValue: Dimensions.get("window").width / 1.6,
                delay: 0,
                useNativeDriver: false,
            }),
            Animated.timing(moveAnim, {
                duration: 2000,
                toValue: 0,
                delay: 0,
                useNativeDriver: false,
            }),
        ]).start();
        Animated.timing(fadeAnim, {
            duration: 2000,
            toValue: 1,
            delay: 2000,
            useNativeDriver: false,
        }).start();
    }, [moveAnim, fadeAnim]);

    const navigation = useNavigation();

    return (
        <SafeAreaView style={styles.container}>
            <View style={styles.contentContainer}>
                <Animated.Image
                    style={[styles.image, { opacity: fadeAnim }]}
                    source={require("./logo.png")}
                />
                <Animated.View
                    style={[styles.logoContainer, { marginLeft: moveAnim }]}
                >
                    <Text style={[styles.logoText]}>Peer</Text>
                    <Animated.Text
                        style={[styles.logoText, { opacity: fadeAnim }]}
                    >
                        2Peer
                    </Animated.Text>
                </Animated.View>
                <Animated.Text
                    style={[styles.logoText2, { opacity: fadeAnim }]}
                >
                    {"\n"} Welcome to our networking App! {"\n"}
                    {"\n"}
                    {"\n"}
                </Animated.Text>

                <Button
                    onPress={() => navigation.navigate("InitialScreen")}
                    title="Click here to start Networking!"
                    color="black"
                />
            </View>
        </SafeAreaView>
    );
};

export default App;

export const styles = StyleSheet.create({
    container: {
        display: "flex",
        flex: 6,
        backgroundColor: "#00000",
    },
    logoText: {
        fontSize: 35,
        marginTop: 0,
        color: "black",
        fontWeight: "700",
    },
    logoText2: {
        fontSize: 15,
        marginTop: 0,
        color: "dark blue",

        fontWeight: "200",
    },
    contentContainer: {
        top: "40%",
        alignItems: "center",
    },
    image: {
        width: 100,
        height: 100,
    },
    logoContainer: {
        flexDirection: "row",
    },
});
