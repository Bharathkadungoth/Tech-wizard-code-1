/**================================================================================================
 **        ABOUT
 * @author    : Aditya Bajaj
 * @createdOn : 02-22-21
 * @modifiedOn : 04-15-21
 * @description : Contains the components to show user dashboard
 *================================================================================================**/

import React from "react";
import {
    StyleSheet,
    Text,
    View,
    Image,
    TextInput,
    TouchableOpacity,
    ScrollView,
    ActivityIndicator,
    StatusBar,
} from "react-native";

import { Feather as Icon, FontAwesome as FAIcon } from "@expo/vector-icons/";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import NotificationScreen from "./Dashboard/NotificationScreen";
import SettingsScreen from "./Dashboard/SettingsScreen";
import { Header } from "react-native-elements";
import { useNavigation } from "@react-navigation/native";

import ExploreScreen from "./Dashboard/Explore";
import ProfileScreen from "./Dashboard/ProfileScreen";
import * as queries from "../src/graphql/queries";

import ChatInvocation from "./Dashboard/chatInvocation";
import ProfileButton from "./Dashboard/ProfileButton";
import { LinearGradient } from "expo-linear-gradient";

function Chats() {
    return (
        <LinearGradient
            colors={["#090979", "#00d4ff"]}
            style={styles.container}
        >
            <Header
                placement="left"
                leftComponent={{
                    text: "Chats",
                    style: { color: "#000", fontSize: 20 },
                }}
                rightComponent={<ProfileButton />}
                containerStyle={{
                    backgroundColor: "wheat",
                }}
            />
            <ChatInvocation />
        </LinearGradient>
    );
}
function Notifications() {
    return (
        <LinearGradient
            colors={["#090979", "#00d4ff"]}
            style={styles.container}
        >
            <ScrollView style={{ ...styles.container }}>
                <Header
                    placement="left"
                    leftComponent={{
                        text: "Notifications",
                        style: { color: "#000", fontSize: 20 },
                    }}
                    rightComponent={<ProfileButton />}
                    containerStyle={{
                        backgroundColor: "wheat",
                    }}
                />
                <NotificationScreen />
            </ScrollView>
        </LinearGradient>
    );
}
function Settings() {
    return (
        <LinearGradient
            colors={["#090979", "#00d4ff"]}
            style={styles.container}
        >
            <Header
                placement="left"
                leftComponent={{
                    text: "Settings",
                    style: { color: "#000", fontSize: 20 },
                }}
                rightComponent={<ProfileButton />}
                containerStyle={{
                    backgroundColor: "wheat",
                }}
            />
            <SettingsScreen />
        </LinearGradient>
    );
}
function Profile() {
    return (
        <View style={{ ...styles.container }}>
            <ProfileScreen />
        </View>
    );
}

const Tab = createBottomTabNavigator();

export default function Dashboard({ navigation }) {
    StatusBar.setBarStyle("light-content", true);
    return (
        <Tab.Navigator initialRouteName="Explore">
            <Tab.Screen
                name="Explore"
                component={ExploreScreen}
                options={{
                    tabBarIcon: ({ color, size }) => (
                        <Icon name="globe" color={color} size={size - 4} />
                    ),
                }}
            />
            <Tab.Screen
                name="Chats"
                component={Chats}
                options={{
                    tabBarIcon: ({ color, size }) => (
                        <Icon
                            name="message-square"
                            color={color}
                            size={size - 4}
                        />
                    ),
                }}
            />
            <Tab.Screen
                name="Notifications"
                component={Notifications}
                options={{
                    // tabBarBadge: 3,
                    tabBarIcon: ({ color, size }) => (
                        <Icon name="bell" color={color} size={size - 4} />
                    ),
                }}
            />
            <Tab.Screen
                name="Settings"
                component={Settings}
                options={{
                    tabBarIcon: ({ color, size }) => (
                        <Icon name="settings" color={color} size={size - 4} />
                    ),
                }}
            />
            <Tab.Screen
                name="Profile"
                component={Profile}
                options={{
                    tabBarIcon: ({ color, size }) => (
                        <Icon name="user" color={color} size={size - 4} />
                    ),
                }}
            />
        </Tab.Navigator>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "#1f1f1f",
    },
    searchBarView: {
        height: 50,
        alignItems: "center",
        flexDirection: "row",
        paddingHorizontal: 10,
    },
    searchBar: {
        flex: 1,
        height: 40,
        backgroundColor: "#3f3f3f",
        marginRight: 10,
        borderRadius: 4,
        paddingLeft: 10,
        flexDirection: "row",
        alignItems: "center",
    },
    userProfileImage: {
        width: 35,
        height: 35,
        borderRadius: 100,
    },
});
