/*@Author

Gayathri Sitaraman

This code can be used by SER 517 TA and instructor
Created and updated: 10th March 2021
*/

import * as React from "react";
// import LoginScreen2 from "./screens/loginScreen2";
import LoginScreen from "./screens/loginScreen";
import Register from "./screens/register";

import { Text, View, Button } from "react-native";

import Amplify, { API, graphqlOperation } from "aws-amplify";
import awsconfig from "./src/aws-exports";
Amplify.configure(awsconfig);

//import { API } from 'aws-amplify';
import { createLogin, updateLogin, deleteLogin } from "./src/graphql/mutations";

const loginDetails = { email: "abcd", password: "pass" };

export default class TestApp extends React.Component {
    det = async () => {
        try {
            console.log("hello");
            const ld = await API.graphql(
                graphqlOperation(createLogin, { input: loginDetails })
            );
            console.log("success");
        } catch (err) {
            console.log("Error", err);
        }
    };

    render() {
        console.log("Come on");
        return (
            <View
                style={{
                    flex: 1,
                    justifyContent: "center",
                    alignItems: "center",
                }}
            >
                <Text>hello</Text>
                <Button onPress={this.det} title="Add login" color="#eeaa55" />
            </View>
        );
    }
}
