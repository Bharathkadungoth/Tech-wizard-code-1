# Peer2Peer Mentoring & social networking mobile application #

<br/>

## ✨Members: ##

1. Aditya Bajaj : anbajaj@asu.edu
2. Gayathri Sitaraman : s.gayu95@gmail.com
3. Prashant Singh : prashantsingh1896@gmail.com
4. Rishika Bera : rishika.bera@gmail.com
5. Swarnalatha Srenigarajan : jain.swarnalatha@gmail.com

Professor: Michael Findler

Sponsor: Melloney Campbell (Startup Canada - Peel Region Community) :  melloneycampbell@gmail.com
 
 
## ✨Techstack : ##
Frontend : React Native
<br/>
Backend : AWS (Amplify, Cognito), GraphQL
<br/>

## ✨Link to Test : ##
https://master.d4zo25pw7l43k.amplifyapp.com/
<br/>
Username : test
<br/>
Password : password
<br/>

## ✨Youtube link to the MVP : ##
https://youtu.be/R2eRaKKgtOg
<br/>

## ✨Installation Guide ##
Introduction
The main Purpose of this document is to help anyone trying to set up this project in their own machine. This document describes the installation instructions to run the software code from the github repository.

### Reference information ###
1. https://www.jcchouinard.com/install-node-and-npm/ - To install npm
2. https://reactnative.dev/docs/environment-setup - React native development setup
3. https://aws.amazon.com/amplify/ - AWS amplify
4. https://docs.aws.amazon.com/cognito/ - AWS Cognito
5. https://graphql.org/learn/ - Graphql

### System Requirements ###
The software installation is simple, and having a good idea of command line tools will be helpful.

Hardware : A laptop or a virtual machine running Windows, Mac, or Linux with at least 8GB of RAM.

Operating Systems : Windows or Mac

### Known problems: ###

If you try running on Expo Go on the phone, there might be issues which are yet to be debugged, as there is no clear picture on them yet. Expo Go seems to be throwing inconsistent errors across different phones.
Installing the App

### Prerequisites ###

A pre-installed npm tool that comes with nodejs is necessary. [1]
Please note:  Node v14.15.5 works 


### Starting the installation

Pull the github link : git clone https://github.com/adityab079/Peer2Peer.git

Perform installation of packages : npm install

Start the app : expo start

### Client Installation
      
Expo terminal lets you run the app in web browser mode as well as on the phone using Expo Go app.
Also, installing Android emulators on Windows and ios emulators on Mac, can help to load the app and run.
Installing System Updates
The packages and their versions are already defined in the package.json file, and if any changes are needed, the future development team will take care of it.

### Troubleshooting

If there are any npm errors, kindly google the error. The most common solution is to delete node_modules folder and do an npm install again.
